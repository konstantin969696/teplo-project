/**
 * Equipment action bar — global tSupply/tReturn inputs (D-09).
 * Wired to projectStore; clamp lives in setter (T-3-01 mitigation).
 * Warns when system is inoperable (tSupply <= avg tInside → LMTD = 0).
 */

import { useState, type ChangeEvent } from 'react'
import { useProjectStore } from '../../store/projectStore'
import { INPUT_CLASS } from './equipment-help'
import { CatalogEditorModal } from './CatalogEditorModal'
import { ColumnHint } from '../ColumnHint'

export function EquipmentActionBar() {
  const tSupply = useProjectStore(s => s.tSupply)
  const tReturn = useProjectStore(s => s.tReturn)
  const setTSupply = useProjectStore(s => s.setTSupply)
  const setTReturn = useProjectStore(s => s.setTReturn)
  const rooms = useProjectStore(s => s.rooms)
  const [showCatalog, setShowCatalog] = useState(false)

  const roomValues = Object.values(rooms)
  const avgTInside = roomValues.length > 0
    ? roomValues.reduce((sum, r) => sum + r.tInside, 0) / roomValues.length
    : 20
  const isInoperable = tSupply <= avgTInside

  const handleNumber = (setter: (n: number) => void) =>
    (e: ChangeEvent<HTMLInputElement>) => {
      const v = parseFloat(e.target.value)
      if (Number.isFinite(v)) setter(v)
    }

  return (
    <div className="flex flex-col gap-2 p-3 border border-[var(--color-border)] rounded-md bg-[var(--color-surface)]">
      <div className="flex items-center gap-4 flex-wrap">
        <label className="flex items-center gap-2 text-sm text-[var(--color-text-primary)]">
          <ColumnHint label="Tподача, °C" hint="Температура горячего теплоносителя на входе в прибор (подача). Стандарт РФ: 80°C или 90°C для радиаторов, 55°C для тёплого пола. Используется вместе с Tобратная для расчёта LMTD." />
          <input
            type="number"
            min={20}
            max={150}
            step={1}
            value={tSupply}
            onChange={handleNumber(setTSupply)}
            className={`${INPUT_CLASS} w-20 font-mono`}
            aria-label="Температура теплоносителя (подача)"
          />
        </label>
        <label className="flex items-center gap-2 text-sm text-[var(--color-text-primary)]">
          <ColumnHint label="Tобратная, °C" hint="Температура охлаждённого теплоносителя на выходе из прибора (обратка). Стандарт РФ: 60°C или 70°C. Разница Tподача − Tобратная обычно 10–20°C." />
          <input
            type="number"
            min={10}
            max={140}
            step={1}
            value={tReturn}
            onChange={handleNumber(setTReturn)}
            className={`${INPUT_CLASS} w-20 font-mono`}
            aria-label="Температура теплоносителя (обратка)"
          />
        </label>
        <button
          type="button"
          onClick={() => setShowCatalog(true)}
          className="ml-auto px-3 py-1 text-xs border border-[var(--color-border)] rounded hover:bg-[var(--color-bg)] text-[var(--color-text-primary)] transition-colors"
          aria-label="Открыть каталог приборов"
        >
          Каталог…
        </button>
      </div>
      {isInoperable && (
        <span className="text-xs text-[var(--color-destructive)]">
          Tподача ниже Tпомещения — система неработоспособна, LMTD = 0
        </span>
      )}
      <CatalogEditorModal open={showCatalog} onClose={() => setShowCatalog(false)} />
    </div>
  )
}
