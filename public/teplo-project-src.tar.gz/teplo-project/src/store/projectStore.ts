/**
 * Zustand store with persist middleware for project state.
 * Persists project data to localStorage key 'teplo-project'.
 * UI-only state (activeTab) excluded via partialize.
 */

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import type { ProjectState, ProjectData, CityData, CustomCityData, Room } from '../types/project'
import type { SchemaType } from '../types/hydraulics'
import { validateProjectJSON } from '../engine/validation'
import { clampTemperature } from '../engine/climate'
import { safeStorage } from './safeStorage'
import { uuid } from './uuid'
import { toast } from 'sonner'

const defaultProjectData: ProjectData = {
  city: null,
  tInside: 20,
  rooms: {},
  roomOrder: [],
  customCities: [],
  tSupply: 80,
  tReturn: 60,
  // Phase 4 defaults (D-04, D-08, D-14)
  schemaType: 'two-pipe-dead-end',
  pipeMaterialId: 'steel-vgp-dn20',
  coolantId: 'water',
  tSupplyUfh: 45,
  tReturnUfh: 35
}

export const useProjectStore = create<ProjectState>()(
  persist(
    (set, get) => ({
      ...defaultProjectData,
      activeTab: 0,

      setCity: (city: CityData | null) => set({ city }),

      setTInside: (t: number) => set({ tInside: clampTemperature(t) }),

      setTSupply: (t: number) => set({ tSupply: Math.max(20, Math.min(150, t)) }),

      setTReturn: (t: number) => set({ tReturn: Math.max(10, Math.min(140, t)) }),

      // Phase 4 setters (D-04, D-08)
      setSchemaType: (s: SchemaType) => set({ schemaType: s }),
      setPipeMaterialId: (id: string) => set({ pipeMaterialId: id }),
      setCoolantId: (id: string) => set({ coolantId: id }),
      setTSupplyUfh: (t: number) => set({ tSupplyUfh: Math.max(30, Math.min(60, t)) }),
      setTReturnUfh: (t: number) => set({ tReturnUfh: Math.max(25, Math.min(55, t)) }),

      setActiveTab: (tab: number) => set({ activeTab: tab }),

      exportJSON: () => {
        const { city, tInside, rooms, roomOrder, customCities, tSupply, tReturn, schemaType, pipeMaterialId, coolantId, tSupplyUfh, tReturnUfh } = get()
        const data: ProjectData = { city, tInside, rooms, roomOrder, customCities, tSupply, tReturn, schemaType, pipeMaterialId, coolantId, tSupplyUfh, tReturnUfh }
        const date = new Date()
        const dd = String(date.getDate()).padStart(2, '0')
        const mm = String(date.getMonth() + 1).padStart(2, '0')
        const yyyy = date.getFullYear()
        const filename = `ТеплоПроект_${dd}.${mm}.${yyyy}.json`
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = filename
        a.click()
        URL.revokeObjectURL(url)
        toast.success('Проект экспортирован')
      },

      importJSON: (data: unknown) => {
        if (!validateProjectJSON(data)) {
          toast.error('Ошибка импорта: файл повреждён или имеет неверный формат')
          return
        }
        // Normalize rooms: Phase 1 JSON may lack Phase 2 fields
        const normalizedRooms: Record<string, Room> = {}
        for (const [id, room] of Object.entries(data.rooms)) {
          const r = room as Record<string, unknown>
          normalizedRooms[id] = {
            id,
            name: r.name as string,
            floor: r.floor as number,
            area: r.area as number,
            height: r.height as number,
            isCorner: (r.isCorner as boolean) ?? false,
            infiltrationMethod: (r.infiltrationMethod as 'rate' | 'gap') ?? 'rate',
            nInfiltration: typeof r.nInfiltration === 'number' ? r.nInfiltration : null,
            gapArea: (r.gapArea as number | null) ?? null,
            windSpeed: (r.windSpeed as number | null) ?? null,
            lVentilation: (r.lVentilation as number) ?? 0,
            tInside: (r.tInside as number) ?? data.tInside ?? 20
          }
        }
        // Phase 3 fields — backward-compat: default to 80/60 if missing/invalid
        const d = data as Record<string, unknown>
        const tSupply = (typeof d.tSupply === 'number' && Number.isFinite(d.tSupply) && d.tSupply >= 20 && d.tSupply <= 150) ? d.tSupply : 80
        const tReturn = (typeof d.tReturn === 'number' && Number.isFinite(d.tReturn) && d.tReturn >= 10 && d.tReturn <= 140) ? d.tReturn : 60
        // Phase 4 fields — backward-compat defaults
        const VALID_SCHEMA_TYPES = new Set(['two-pipe-dead-end', 'two-pipe-flow-through', 'manifold', 'single-pipe'])
        const schemaType = (typeof d.schemaType === 'string' && VALID_SCHEMA_TYPES.has(d.schemaType))
          ? d.schemaType as SchemaType
          : 'two-pipe-dead-end'
        const pipeMaterialId = (typeof d.pipeMaterialId === 'string' && d.pipeMaterialId.length > 0) ? d.pipeMaterialId : 'steel-vgp-dn20'
        const coolantId = (typeof d.coolantId === 'string' && d.coolantId.length > 0) ? d.coolantId : 'water'
        const tSupplyUfh = (typeof d.tSupplyUfh === 'number' && Number.isFinite(d.tSupplyUfh) && d.tSupplyUfh >= 20 && d.tSupplyUfh <= 80) ? d.tSupplyUfh : 45
        const tReturnUfh = (typeof d.tReturnUfh === 'number' && Number.isFinite(d.tReturnUfh) && d.tReturnUfh >= 15 && d.tReturnUfh <= 70) ? d.tReturnUfh : 35
        set({
          city: data.city,
          tInside: data.tInside,
          rooms: normalizedRooms,
          roomOrder: data.roomOrder,
          customCities: data.customCities ?? [],
          tSupply,
          tReturn,
          schemaType,
          pipeMaterialId,
          coolantId,
          tSupplyUfh,
          tReturnUfh
        })
        toast.success('Проект загружен')
      },

      resetProject: () => set({ ...defaultProjectData }),

      addCustomCity: (cityInput) => set(state => ({
        customCities: [...state.customCities, { ...cityInput, id: uuid(), isCustom: true as const }]
      })),

      updateCustomCity: (id, cityInput) => set(state => {
        const updated: CustomCityData = { ...cityInput, id, isCustom: true as const }
        const customCities = state.customCities.map(c => c.id === id ? updated : c)
        const city = (state.city && 'id' in state.city && (state.city as CustomCityData).id === id)
          ? updated
          : state.city
        return { customCities, city }
      }),

      deleteCustomCity: (id) => set(state => {
        const customCities = state.customCities.filter(c => c.id !== id)
        const city = (state.city && 'id' in state.city && (state.city as CustomCityData).id === id)
          ? null
          : state.city
        return { customCities, city }
      }),

      addRoom: (room: Omit<Room, 'id'>) => set((state) => {
        const id = uuid()
        return {
          rooms: { ...state.rooms, [id]: { ...room, id } },
          roomOrder: [...state.roomOrder, id]
        }
      }),

      updateRoom: (id: string, changes: Partial<Omit<Room, 'id'>>) => set(state => ({
        rooms: {
          ...state.rooms,
          [id]: { ...state.rooms[id], ...changes }
        }
      })),

      deleteRoom: (id: string) => set(state => {
        const { [id]: _, ...rooms } = state.rooms
        return {
          rooms,
          roomOrder: state.roomOrder.filter(rid => rid !== id)
        }
      })
    }),
    {
      name: 'teplo-project',
      storage: createJSONStorage(() => safeStorage),
      partialize: (state) => ({
        city: state.city,
        tInside: state.tInside,
        rooms: state.rooms,
        roomOrder: state.roomOrder,
        customCities: state.customCities,
        tSupply: state.tSupply,
        tReturn: state.tReturn,
        schemaType: state.schemaType,
        pipeMaterialId: state.pipeMaterialId,
        coolantId: state.coolantId,
        tSupplyUfh: state.tSupplyUfh,
        tReturnUfh: state.tReturnUfh
      } as unknown as ProjectState),
      onRehydrateStorage: () => (state, error) => {
        if (error) {
          console.error('Rehydration failed:', error)
          return
        }
        // Backward-compat: older saves did not have Room.number. Fill it with
        // roomOrder position (1-based) so existing projects don't break.
        if (state && state.roomOrder && state.rooms) {
          const patched: Record<string, Room> = { ...state.rooms }
          let changed = false
          state.roomOrder.forEach((id, idx) => {
            const r = patched[id] as Room | undefined
            if (r && (typeof (r as unknown as { number?: unknown }).number !== 'number')) {
              patched[id] = { ...r, number: idx + 1 }
              changed = true
            }
          })
          if (changed) state.rooms = patched
        }
      }
    }
  )
)

/** Selector -- deltaT computed on the fly, NOT stored */
export const selectDeltaT = (state: ProjectState): number | null =>
  state.city ? state.tInside - state.city.tOutside : null
