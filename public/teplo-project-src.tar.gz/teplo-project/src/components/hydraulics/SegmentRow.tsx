/**
 * SegmentRow — accordion строка участка гидравлики.
 * Compact: №/назначение/Q/L/d_пр/v/ΔP + кнопка удаления.
 * Expanded: SegmentDetails с технической информацией + FormulaAudit.
 * ГЦК подсветка через var(--gck-bg) + border-l-4 border-l-[var(--gck-strip)].
 *
 * Decisions:
 *   D-02: Q — readonly если equipmentId заполнен (auto), иначе editable.
 *   D-11: ГЦК highlight через CSS tokens.
 */

import { useMemo, useState } from 'react'
import { ChevronRight } from 'lucide-react'
import { useShallow } from 'zustand/react/shallow'
import { useSegmentStore } from '../../store/segmentStore'
import { useEquipmentStore } from '../../store/equipmentStore'
import { useProjectStore } from '../../store/projectStore'
import { SegmentDetails } from './SegmentDetails'
import { KmsPicker } from './KmsPicker'
import { INPUT_CLASS, formatDeltaP, formatVelocity, formatDiameter } from './hydraulics-help'
import { buildEquipmentOptions } from './equipment-label'
import type { SegmentCalcResult } from '../../engine/hydraulics'

// Легаси-паттерны автогенерированных имён (до Вариант-1 очистки).
// Если имя матчит — считаем его пустым и показываем плейсхолдер.
const LEGACY_NAME_PATTERN = /^(Участок|К прибору)\s+[a-z0-9]{4}$/i

interface SegmentRowProps {
  readonly segmentId: string
  readonly index: number
  readonly calcResult: SegmentCalcResult | undefined
  readonly isInMainCircuit: boolean
}

export function SegmentRow({ segmentId, index, calcResult, isInMainCircuit }: SegmentRowProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [showKmsPicker, setShowKmsPicker] = useState(false)

  const segment = useSegmentStore(s => s.segments[segmentId])
  const updateSegment = useSegmentStore(s => s.updateSegment)
  const deleteSegment = useSegmentStore(s => s.deleteSegment)

  const equipmentMap = useEquipmentStore(useShallow(s => s.equipment))
  const equipmentOrder = useEquipmentStore(useShallow(s => s.equipmentOrder))
  const rooms = useProjectStore(useShallow(s => s.rooms))

  const equipmentOptions = useMemo(
    () => buildEquipmentOptions(equipmentOrder, equipmentMap, rooms),
    [equipmentOrder, equipmentMap, rooms]
  )
  const boundLabel = useMemo(() => {
    if (!segment?.equipmentId) return null
    return equipmentOptions.find(o => o.id === segment.equipmentId)?.label ?? null
  }, [segment?.equipmentId, equipmentOptions])

  if (!segment) return null

  const zebraClass = index % 2 === 0 ? 'bg-[var(--color-bg)]' : 'bg-[var(--color-surface)]'
  const rowClass = isInMainCircuit
    ? 'bg-[var(--gck-bg)] border-l-4 border-l-[var(--gck-strip)]'
    : zebraClass

  // D-02: Q auto если equipmentId есть и нет qOverride
  const qIsAuto = segment.equipmentId !== null && segment.qOverride === null

  const handleDelete = () => {
    if (window.confirm(`Удалить участок «${segment.name}»? Все данные потеряются.`)) {
      deleteSegment(segmentId)
    }
  }

  return (
    <>
      <tr
        className={`h-10 cursor-pointer hover:bg-[var(--color-surface)] ${rowClass}`}
        onClick={() => setIsExpanded(v => !v)}
        aria-expanded={isExpanded}
      >
        <td className="px-2 py-1">
          <ChevronRight
            size={14}
            className={`transition-transform duration-200 text-[var(--color-text-secondary)] ${isExpanded ? 'rotate-90' : ''}`}
            aria-hidden="true"
          />
        </td>
        <td className="text-center font-mono text-xs text-[var(--color-text-secondary)]">
          {index + 1}
        </td>
        <td className="px-2 py-1">
          <div className="flex items-center gap-2">
            <select
              value={segment.equipmentId ?? ''}
              onClick={e => e.stopPropagation()}
              onChange={e => {
                const v = e.target.value || null
                updateSegment(segmentId, { equipmentId: v })
              }}
              className={`${INPUT_CLASS} w-44 shrink-0`}
              aria-label="Привязать к прибору"
              title="Прибор, к которому подводит этот участок"
            >
              <option value="">— свободный —</option>
              {equipmentOptions.map(opt => (
                <option key={opt.id} value={opt.id}>{opt.label}</option>
              ))}
            </select>
            {boundLabel ? (
              <span
                className="flex-1 truncate text-sm text-[var(--color-text-primary)] font-medium"
                title={boundLabel}
              >
                {boundLabel}
              </span>
            ) : (
              <input
                type="text"
                defaultValue={LEGACY_NAME_PATTERN.test(segment.name) ? '' : segment.name}
                onClick={e => e.stopPropagation()}
                onBlur={e => updateSegment(segmentId, { name: e.target.value.trim() })}
                className={`${INPUT_CLASS} flex-1 min-w-0`}
                aria-label="Назначение участка"
                placeholder={`Участок №${index + 1} — напр.: магистраль, стояк`}
              />
            )}
          </div>
        </td>
        <td className="text-right px-2 font-mono text-xs">
          {qIsAuto ? (
            <span className="text-[var(--color-text-secondary)]">
              {calcResult?.qWatts != null && calcResult.qWatts > 0
                ? calcResult.qWatts.toFixed(0)
                : '—'}
            </span>
          ) : (
            <input
              type="number"
              defaultValue={segment.qOverride ?? 0}
              onClick={e => e.stopPropagation()}
              onBlur={e => updateSegment(segmentId, { qOverride: parseFloat(e.target.value) || null })}
              className={`${INPUT_CLASS} w-20 text-right font-mono`}
              aria-label="Q, Вт"
            />
          )}
        </td>
        <td className="text-right px-2 font-mono text-xs">
          <input
            type="number"
            step="0.1"
            defaultValue={segment.lengthM}
            onClick={e => e.stopPropagation()}
            onBlur={e => updateSegment(segmentId, { lengthM: parseFloat(e.target.value) || 0 })}
            className={`${INPUT_CLASS} w-16 text-right font-mono`}
            aria-label="Длина участка, м"
          />
        </td>
        <td className="text-right px-2 font-mono text-xs">
          {formatDiameter(calcResult?.selectedPipe?.innerDiameterMm ?? null)}
        </td>
        <td className="text-right px-2 font-mono text-xs">
          {formatVelocity(calcResult?.velocityMS ?? 0)}
        </td>
        <td className="text-right px-2 font-mono text-xs font-semibold">
          {formatDeltaP(calcResult?.deltaPTotalPa ?? 0)}
        </td>
        <td className="text-center px-2">
          <button
            type="button"
            onClick={e => { e.stopPropagation(); handleDelete() }}
            className="text-[var(--color-destructive)] hover:underline text-xs"
            aria-label="Удалить участок"
          >
            ✕
          </button>
        </td>
      </tr>

      {isExpanded && (
        <tr>
          <td colSpan={9} className="p-0">
            <SegmentDetails
              segment={segment}
              calcResult={calcResult}
              onOpenKmsPicker={() => setShowKmsPicker(true)}
            />
          </td>
        </tr>
      )}

      {showKmsPicker && (
        <KmsPicker
          segmentId={segmentId}
          open={showKmsPicker}
          onClose={() => setShowKmsPicker(false)}
        />
      )}
    </>
  )
}
