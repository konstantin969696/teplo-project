/**
 * HydraulicsActionBar — action bar таба «Гидравлика».
 * Содержит: selectors (схема/теплоноситель/тип труб), кнопки «Добавить участок» / «Автогенерация скелета»,
 * и три кнопки «Каталог…» с соответствующими модалками.
 *
 * Decisions:
 *   D-01: handleAutogenerate создаёт магистраль + по одному участку на каждый equipment.
 *   D-04: schemaType — метка для PDF, не влияет на расчёт.
 */

import { useState } from 'react'
import { Plus } from 'lucide-react'
import { useShallow } from 'zustand/react/shallow'
import { useProjectStore } from '../../store/projectStore'
import { useSegmentStore } from '../../store/segmentStore'
import { useCoolantCatalogStore } from '../../store/coolantCatalogStore'
import { usePipeCatalogStore } from '../../store/pipeCatalogStore'
import { useEquipmentStore } from '../../store/equipmentStore'
import { Button } from '../ui/Button'
import { PipeCatalogModal } from './PipeCatalogModal'
import { KmsCatalogModal } from './KmsCatalogModal'
import { CoolantCatalogModal } from './CoolantCatalogModal'
import { INPUT_CLASS, SCHEMA_LABELS, PIPE_MATERIAL_LABELS } from './hydraulics-help'
import type { SchemaType } from '../../types/hydraulics'

export function HydraulicsActionBar() {
  const schemaType = useProjectStore(s => s.schemaType)
  const setSchemaType = useProjectStore(s => s.setSchemaType)
  const coolantId = useProjectStore(s => s.coolantId)
  const setCoolantId = useProjectStore(s => s.setCoolantId)
  const pipeMaterialId = useProjectStore(s => s.pipeMaterialId)
  const setPipeMaterialId = useProjectStore(s => s.setPipeMaterialId)

  const coolants = useCoolantCatalogStore(useShallow(s => Object.values(s.coolants)))
  const pipes = usePipeCatalogStore(useShallow(s => Object.values(s.pipes)))
  const equipment = useEquipmentStore(useShallow(s => Object.values(s.equipment)))

  const addSegment = useSegmentStore(s => s.addSegment)
  const bulkAddSegments = useSegmentStore(s => s.bulkAddSegments)

  const [showPipeCatalog, setShowPipeCatalog] = useState(false)
  const [showKmsCatalog, setShowKmsCatalog] = useState(false)
  const [showCoolantCatalog, setShowCoolantCatalog] = useState(false)

  const handleAddSegment = () => {
    addSegment({
      parentSegmentId: null,
      name: '',
      equipmentId: null,
      qOverride: null,
      lengthM: 0,
      pipeId: pipeMaterialId,
      dnMm: null,
      kmsCounts: {},
      velocityTargetMS: 0.6,
    })
  }

  const handleAutogenerate = () => {
    // D-01: скелет — магистраль + по одному участку на каждый equipment
    const segments = [
      {
        parentSegmentId: null as string | null,
        name: 'Магистраль',
        equipmentId: null,
        qOverride: null,
        lengthM: 0,
        pipeId: pipeMaterialId,
        dnMm: null,
        kmsCounts: {},
        velocityTargetMS: 0.6,
      },
      ...equipment.map(eq => ({
        parentSegmentId: null as string | null,
        name: '',
        equipmentId: eq.id,
        qOverride: null,
        lengthM: 0,
        pipeId: pipeMaterialId,
        dnMm: null,
        kmsCounts: {},
        velocityTargetMS: 0.3,
      }))
    ]
    bulkAddSegments(segments)
  }

  return (
    <div className="flex flex-col gap-2 p-3 border border-[var(--color-border)] rounded-md bg-[var(--color-surface)]">
      <div className="flex items-center gap-4 flex-wrap">
        <label className="flex items-center gap-2 text-sm">
          <span>Схема отопления:</span>
          <select
            value={schemaType}
            onChange={e => setSchemaType(e.target.value as SchemaType)}
            className={INPUT_CLASS}
            aria-label="Схема отопления"
          >
            {Object.entries(SCHEMA_LABELS).map(([v, label]) => (
              <option key={v} value={v}>{label}</option>
            ))}
          </select>
        </label>

        <label className="flex items-center gap-2 text-sm">
          <span>Теплоноситель:</span>
          <select
            value={coolantId}
            onChange={e => setCoolantId(e.target.value)}
            className={INPUT_CLASS}
            aria-label="Теплоноситель"
          >
            {coolants.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label>

        <label className="flex items-center gap-2 text-sm">
          <span>Тип труб:</span>
          <select
            value={pipeMaterialId}
            onChange={e => setPipeMaterialId(e.target.value)}
            className={INPUT_CLASS}
            aria-label="Тип труб"
          >
            {pipes.map(p => (
              <option key={p.id} value={p.id}>
                {`${PIPE_MATERIAL_LABELS[p.material] ?? p.material} DN${p.dnMm}`}
              </option>
            ))}
          </select>
        </label>

        <Button variant="primary" size="sm" onClick={handleAddSegment} icon={<Plus size={14} />} aria-label="Добавить участок">
          Добавить участок
        </Button>

        <Button variant="secondary" size="sm" onClick={handleAutogenerate} disabled={equipment.length === 0}>
          Автогенерация скелета
        </Button>

        <div className="flex gap-2 ml-auto">
          <Button variant="secondary" size="sm" onClick={() => setShowPipeCatalog(true)}>
            Каталог труб…
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setShowKmsCatalog(true)}>
            Каталог КМС…
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setShowCoolantCatalog(true)}>
            Каталог теплоносителей…
          </Button>
        </div>
      </div>

      <PipeCatalogModal open={showPipeCatalog} onClose={() => setShowPipeCatalog(false)} />
      <KmsCatalogModal open={showKmsCatalog} onClose={() => setShowKmsCatalog(false)} />
      <CoolantCatalogModal open={showCoolantCatalog} onClose={() => setShowCoolantCatalog(false)} />
    </div>
  )
}
