/**
 * UFH loop row — accordion row per room.
 * Compact: checkbox | name | F_тп input | покрытие select | труба select | шаг input | q | warn-icon
 * Expanded: UfhLoopDetails (t_пол, Q_тп, L, N, ΔP, FormulaAudit, UfhWarnings)
 *
 * Paттерн P5 (EquipmentRow accordion) + P6 (derived selector).
 * Derived: qPerM2, qTpW, floorTempC, qRoomW — через useMemo, не хранятся в store.
 * Pipe filter: только трубы с maxLoopLengthM !== null (PE-X/PE-RT/MLCP).
 * F_тп default: Math.round(room.area * 0.8 * 10) / 10 (D-07).
 *
 * Threats mitigated:
 *   T-04-15: React escapes room.name in JSX automatically.
 *   T-04-16: useMemo guards against re-computation on every render.
 *   T-04-17: handleAreaCommit clamps F_тп to [0, room.area].
 */

import { useState, useMemo } from 'react'
import { useShallow } from 'zustand/react/shallow'
import { ChevronRight, AlertTriangle } from 'lucide-react'
import type { Room } from '../../types/project'
import type { FloorCovering } from '../../types/hydraulics'
import { useUfhLoopStore, selectLoopByRoom } from '../../store/ufhLoopStore'
import { useProjectStore } from '../../store/projectStore'
import { usePipeCatalogStore } from '../../store/pipeCatalogStore'
import { useEnclosureStore, selectEnclosuresByRoom } from '../../store/enclosureStore'
import { calculateHeatFlux, calculateFloorTemp } from '../../engine/ufh'
import { calculateRoomTotals } from '../../engine/heatLoss'
import {
  COVERING_LABELS,
  INPUT_CLASS,
  floorTempThresholdC,
  isBathroomRoom,
  formatQPerM2,
} from './ufh-help'
import { PIPE_MATERIAL_LABELS } from '../hydraulics/hydraulics-help'
import { UfhLoopDetails } from './UfhLoopDetails'

interface UfhLoopRowProps {
  readonly room: Room
  readonly index: number
}

export function UfhLoopRow({ room, index }: UfhLoopRowProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  const loop = useUfhLoopStore(useShallow(selectLoopByRoom(room.id)))
  const addLoop = useUfhLoopStore(s => s.addLoop)
  const updateLoop = useUfhLoopStore(s => s.updateLoop)
  const toggleEnabled = useUfhLoopStore(s => s.toggleEnabled)

  const tSupplyUfh = useProjectStore(s => s.tSupplyUfh)
  const tReturnUfh = useProjectStore(s => s.tReturnUfh)
  const tOutside = useProjectStore(s => s.city?.tOutside ?? null)

  // Only UFH-compatible pipes (PE-X / PE-RT / MLCP): maxLoopLengthM !== null
  const pipes = usePipeCatalogStore(
    useShallow(s => Object.values(s.pipes).filter(p => p.maxLoopLengthM !== null))
  )

  const enclosures = useEnclosureStore(useShallow(selectEnclosuresByRoom(room.id)))

  // D-07: F_тп default = 80% of room area, min 1 m²
  const defaultAreaM2 = Math.max(1, Math.round(room.area * 0.8 * 10) / 10)
  const defaultPipeId = pipes[0]?.id ?? ''

  /**
   * Ensures a loop exists in the store for this room.
   * Returns the loop (existing or freshly created stub).
   */
  const ensureLoop = () => {
    if (loop) return loop
    const id = addLoop({
      roomId: room.id,
      enabled: true,
      activeAreaM2: defaultAreaM2,
      covering: 'tile',
      pipeId: defaultPipeId,
      stepCm: 20,
      leadInM: 3,
    })
    return {
      id,
      roomId: room.id,
      enabled: true,
      activeAreaM2: defaultAreaM2,
      covering: 'tile' as FloorCovering,
      pipeId: defaultPipeId,
      stepCm: 20,
      leadInM: 3,
    }
  }

  // Derived q / Q_тп / t_пол / Q_пом — T-04-16: useMemo guards re-computation
  const { qPerM2, qTpW, floorTempC, qRoomW } = useMemo(() => {
    const effectiveCovering = loop?.covering ?? 'tile'
    const effectiveArea = loop?.activeAreaM2 ?? defaultAreaM2
    const isEnabled = loop?.enabled ?? false

    // qPerM2 считается всегда (preview для выключенной петли — видно эффект смены покрытия/темп).
    const q = calculateHeatFlux(tSupplyUfh, tReturnUfh, room.tInside, effectiveCovering)
    const tFloor = calculateFloorTemp(q, room.tInside)

    if (!isEnabled) {
      return { qPerM2: q, qTpW: 0, floorTempC: tFloor, qRoomW: 0 }
    }

    const qTotal = q * effectiveArea
    const deltaT = tOutside !== null ? Math.max(0, room.tInside - tOutside) : 0
    const qRoom = deltaT > 0 ? calculateRoomTotals(enclosures, room, deltaT).qTotal : 0

    return { qPerM2: q, qTpW: qTotal, floorTempC: tFloor, qRoomW: qRoom }
  }, [loop, tSupplyUfh, tReturnUfh, room, enclosures, tOutside, defaultAreaM2])

  const threshold = floorTempThresholdC(room.name)
  const bathroom = isBathroomRoom(room.name)
  // Предупреждения — только для включённых петель (для preview q не имеет смысла).
  const hasWarning =
    loop?.enabled === true &&
    ((qTpW > 0 && qRoomW > 0 && qTpW < qRoomW) || floorTempC > threshold)

  const zebraClass = index % 2 === 0 ? 'bg-[var(--color-bg)]' : 'bg-[var(--color-surface)]'

  // T-04-17: clamp F_тп to [0, room.area]
  const handleAreaCommit = (v: number) => {
    const safe = Math.max(0, Math.min(room.area, v))
    const existing = ensureLoop()
    updateLoop(existing.id, { activeAreaM2: safe })
  }

  return (
    <>
      <tr
        className={`h-10 cursor-pointer hover:bg-[var(--color-surface)] ${zebraClass}`}
        onClick={() => setIsExpanded(v => !v)}
        aria-expanded={isExpanded}
      >
        <td className="px-2 py-1">
          <ChevronRight
            size={14}
            className={`transition-transform duration-200 text-[var(--color-text-secondary)] ${isExpanded ? 'rotate-90' : ''}`}
            aria-hidden="true"
          />
        </td>
        <td className="px-2 py-1">
          <label
            className="flex items-center gap-2"
            onClick={e => e.stopPropagation()}
          >
            <input
              type="checkbox"
              checked={loop?.enabled ?? false}
              onChange={() => {
                const l = ensureLoop()
                toggleEnabled(l.id)
              }}
              aria-label={`Включить тёплый пол для ${room.name}`}
            />
            <span className="text-sm text-[var(--color-text-primary)]">
              {room.name}
            </span>
          </label>
        </td>
        <td className="px-2 py-1 text-right">
          <input
            type="number"
            step={0.1}
            min={0}
            max={room.area}
            defaultValue={loop?.activeAreaM2 ?? defaultAreaM2}
            key={loop?.id ?? 'default-area'}
            onClick={e => e.stopPropagation()}
            onBlur={e => handleAreaCommit(parseFloat(e.target.value) || 0)}
            className={`${INPUT_CLASS} w-20 text-right font-mono`}
            aria-label="F_тп, м²"
          />
        </td>
        <td className="px-2 py-1">
          <select
            value={loop?.covering ?? 'tile'}
            onClick={e => e.stopPropagation()}
            onChange={e => {
              const l = ensureLoop()
              updateLoop(l.id, { covering: e.target.value as FloorCovering })
            }}
            className={INPUT_CLASS}
            aria-label="Покрытие"
          >
            {(Object.entries(COVERING_LABELS) as [FloorCovering, string][]).map(([v, label]) => (
              <option key={v} value={v}>{label}</option>
            ))}
          </select>
        </td>
        <td className="px-2 py-1">
          <select
            value={loop?.pipeId ?? defaultPipeId}
            onClick={e => e.stopPropagation()}
            onChange={e => {
              const l = ensureLoop()
              updateLoop(l.id, { pipeId: e.target.value })
            }}
            className={INPUT_CLASS}
            aria-label="Труба ТП"
          >
            {pipes.map(p => (
              <option key={p.id} value={p.id}>
                {PIPE_MATERIAL_LABELS[p.material] ?? p.material} {p.dnMm}×{p.wallThicknessMm}
              </option>
            ))}
          </select>
        </td>
        <td className="px-2 py-1 text-right">
          <input
            type="number"
            min={10}
            max={30}
            step={5}
            defaultValue={loop?.stepCm ?? 20}
            key={loop?.id ?? 'default-step'}
            onClick={e => e.stopPropagation()}
            onBlur={e => {
              const l = ensureLoop()
              updateLoop(l.id, { stepCm: parseFloat(e.target.value) || 20 })
            }}
            className={`${INPUT_CLASS} w-16 text-right font-mono`}
            aria-label="Шаг укладки, см"
          />
        </td>
        <td
          className={`px-2 py-1 text-right font-mono ${
            loop?.enabled
              ? 'text-[var(--color-text-primary)]'
              : 'text-[var(--color-text-secondary)] italic'
          }`}
          title={loop?.enabled ? undefined : 'Предварительный расчёт. Включите петлю галкой слева чтобы применить мощность'}
        >
          {formatQPerM2(qPerM2)}
        </td>
        <td className="px-2 py-1 text-center">
          {hasWarning && (
            <AlertTriangle
              size={14}
              className={
                floorTempC > threshold
                  ? 'text-[var(--color-destructive)]'
                  : 'text-[var(--color-warning)]'
              }
              aria-label="Предупреждение"
            />
          )}
        </td>
      </tr>

      {isExpanded && loop && (
        <tr>
          <td colSpan={8} className="p-0">
            <UfhLoopDetails
              room={room}
              loop={loop}
              qPerM2={qPerM2}
              qTpW={qTpW}
              floorTempC={floorTempC}
              qRoomW={qRoomW}
              threshold={threshold}
              isBathroom={bathroom}
            />
          </td>
        </tr>
      )}
    </>
  )
}
