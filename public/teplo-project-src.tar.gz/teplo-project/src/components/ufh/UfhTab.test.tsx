/**
 * Tests for UfhTab component.
 * Covers: empty state, with rooms, ActionBar + Table rendering.
 */

import '@testing-library/jest-dom/vitest'
import { describe, it, expect, beforeEach, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import { UfhTab } from './UfhTab'
import { useProjectStore } from '../../store/projectStore'

// Mock child components to isolate UfhTab logic
vi.mock('./UfhActionBar', () => ({
  UfhActionBar: () => <div data-testid="ufh-action-bar">ActionBar</div>,
}))

vi.mock('./UfhTable', () => ({
  UfhTable: () => <div data-testid="ufh-table">Table</div>,
}))

describe('UfhTab', () => {
  beforeEach(() => {
    useProjectStore.setState({
      rooms: {},
      roomOrder: [],
    })
  })

  it('Test 3 (UfhTab empty): без помещений показывает EmptyTabState', () => {
    render(<UfhTab />)
    expect(screen.getByText('Нет помещений')).toBeInTheDocument()
    expect(screen.getByText(/Помещения появятся автоматически/)).toBeInTheDocument()
  })

  it('Test 3b (UfhTab empty): всегда показывает ActionBar', () => {
    render(<UfhTab />)
    expect(screen.getByTestId('ufh-action-bar')).toBeInTheDocument()
  })

  it('Test 4 (UfhTab with rooms): отрисовывает UfhActionBar + UfhTable', () => {
    useProjectStore.setState({
      rooms: {
        'room-1': {
          id: 'room-1',
          name: 'Гостиная',
          floor: 1,
          area: 20,
          height: 2.7,
          tInside: 20,
          isCorner: false,
          infiltrationMethod: 'rate',
          nInfiltration: null,
          gapArea: null,
          windSpeed: null,
          lVentilation: 0,
        },
      },
      roomOrder: ['room-1'],
    })
    render(<UfhTab />)
    expect(screen.getByTestId('ufh-action-bar')).toBeInTheDocument()
    expect(screen.getByTestId('ufh-table')).toBeInTheDocument()
    expect(screen.queryByText('Нет помещений')).not.toBeInTheDocument()
  })
})
