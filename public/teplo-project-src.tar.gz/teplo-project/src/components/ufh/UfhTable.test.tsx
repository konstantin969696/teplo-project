/**
 * Tests for UfhTable component.
 * Covers: renders UfhLoopRow for each room, table headers.
 */

import '@testing-library/jest-dom/vitest'
import { describe, it, expect, beforeEach, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import { UfhTable } from './UfhTable'
import { useProjectStore } from '../../store/projectStore'

// Mock UfhLoopRow to isolate table logic
vi.mock('./UfhLoopRow', () => ({
  UfhLoopRow: ({ room }: { room: { name: string } }) => (
    <tr data-testid={`ufh-loop-row-${room.name}`}>
      <td>{room.name}</td>
    </tr>
  ),
}))

const ROOM_1 = {
  id: 'room-1',
  name: 'Гостиная',
  floor: 1,
  area: 20,
  height: 2.7,
  tInside: 20,
  isCorner: false,
  infiltrationMethod: 'rate' as const,
  nInfiltration: null,
  gapArea: null,
  windSpeed: null,
  lVentilation: 0,
}

const ROOM_2 = {
  id: 'room-2',
  name: 'Спальня',
  floor: 1,
  area: 15,
  height: 2.7,
  tInside: 20,
  isCorner: false,
  infiltrationMethod: 'rate' as const,
  nInfiltration: null,
  gapArea: null,
  windSpeed: null,
  lVentilation: 0,
}

describe('UfhTable', () => {
  beforeEach(() => {
    useProjectStore.setState({
      rooms: {
        'room-1': ROOM_1,
        'room-2': ROOM_2,
      },
      roomOrder: ['room-1', 'room-2'],
    })
  })

  it('Test 8 (UfhTable): отрисовывает UfhLoopRow для каждой room в roomOrder', () => {
    render(<UfhTable />)
    expect(screen.getByTestId('ufh-loop-row-Гостиная')).toBeInTheDocument()
    expect(screen.getByTestId('ufh-loop-row-Спальня')).toBeInTheDocument()
  })

  it('Test 9 (UfhTable headers): колонка Помещение', () => {
    render(<UfhTable />)
    expect(screen.getByText('Помещение')).toBeInTheDocument()
  })

  it('Test 9b (UfhTable headers): колонка F_тп, м²', () => {
    render(<UfhTable />)
    expect(screen.getByText('F_тп, м²')).toBeInTheDocument()
  })

  it('Test 9c (UfhTable headers): колонка Покрытие', () => {
    render(<UfhTable />)
    expect(screen.getByText('Покрытие')).toBeInTheDocument()
  })

  it('Test 9d (UfhTable headers): колонка Труба ТП', () => {
    render(<UfhTable />)
    expect(screen.getByText('Труба ТП')).toBeInTheDocument()
  })

  it('Test 9e (UfhTable headers): колонка Шаг, см', () => {
    render(<UfhTable />)
    expect(screen.getByText('Шаг, см')).toBeInTheDocument()
  })

  it('Test 9f (UfhTable headers): колонка q, Вт/м²', () => {
    render(<UfhTable />)
    expect(screen.getByText('q, Вт/м²')).toBeInTheDocument()
  })
})
