/**
 * Tests for HydraulicsTab orchestrator.
 * Covers: empty state (no segments), segments present (shows table blocks).
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, render, screen } from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { HydraulicsTab } from './HydraulicsTab'
import { useSegmentStore } from '../../store/segmentStore'
import { useProjectStore } from '../../store/projectStore'
import { useCoolantCatalogStore } from '../../store/coolantCatalogStore'
import { usePipeCatalogStore } from '../../store/pipeCatalogStore'

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}))

beforeEach(() => {
  act(() => {
    useSegmentStore.setState({ segments: {}, segmentOrder: [] })
    useCoolantCatalogStore.getState().resetToSeed()
    usePipeCatalogStore.getState().resetToSeed()
    useProjectStore.setState({
      schemaType: 'two-pipe-dead-end',
      coolantId: 'water',
      pipeMaterialId: 'steel-vgp-dn20',
    })
  })
})

afterEach(() => {
  vi.restoreAllMocks()
})

describe('HydraulicsTab', () => {
  it('shows empty state when no segments', () => {
    render(<HydraulicsTab />)
    expect(screen.getByText('Нет участков')).toBeInTheDocument()
    expect(screen.getByText(/Нажмите «Добавить участок»/i)).toBeInTheDocument()
  })

  it('shows HydraulicsActionBar regardless of segment count', () => {
    render(<HydraulicsTab />)
    expect(screen.getByLabelText('Схема отопления')).toBeInTheDocument()
  })

  it('shows SegmentTable when segments exist', () => {
    act(() => {
      useSegmentStore.getState().addSegment({
        parentSegmentId: null,
        name: 'Магистраль',
        equipmentId: null,
        qOverride: null,
        lengthM: 5,
        pipeId: 'steel-vgp-dn20',
        dnMm: null,
        kmsCounts: {},
        velocityTargetMS: 0.6,
      })
    })
    render(<HydraulicsTab />)
    // empty state should NOT be visible
    expect(screen.queryByText('Нет участков')).not.toBeInTheDocument()
    // table header visible
    expect(screen.getByText('Назначение')).toBeInTheDocument()
  })

  it('shows PumpRecommendation block when segments exist', () => {
    act(() => {
      useSegmentStore.getState().addSegment({
        parentSegmentId: null,
        name: 'Тест',
        equipmentId: null,
        qOverride: null,
        lengthM: 1,
        pipeId: 'steel-vgp-dn20',
        dnMm: null,
        kmsCounts: {},
        velocityTargetMS: 0.6,
      })
    })
    render(<HydraulicsTab />)
    expect(screen.getByText('Рекомендация насоса')).toBeInTheDocument()
  })

  it('shows BalancingBlock when segments exist', () => {
    act(() => {
      useSegmentStore.getState().addSegment({
        parentSegmentId: null,
        name: 'Тест',
        equipmentId: null,
        qOverride: null,
        lengthM: 1,
        pipeId: 'steel-vgp-dn20',
        dnMm: null,
        kmsCounts: {},
        velocityTargetMS: 0.6,
      })
    })
    render(<HydraulicsTab />)
    expect(screen.getByText('Балансировка параллельных ветвей')).toBeInTheDocument()
  })
})
