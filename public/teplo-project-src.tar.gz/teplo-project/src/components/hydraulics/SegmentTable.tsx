/**
 * SegmentTable — таблица участков гидравлики.
 * Рендерит SegmentRow для каждого участка из segmentStore.
 * ГЦК-множество передаётся через useGckPath hook.
 */

import { useMemo } from 'react'
import { useSegmentStore } from '../../store/segmentStore'
import { useGckPath } from './useGckPath'
import { SegmentRow } from './SegmentRow'
import { ColumnHint } from '../ColumnHint'
import { HYDRO_HINTS } from './glossary'

export function SegmentTable() {
  const segmentOrder = useSegmentStore(s => s.segmentOrder)
  const { segmentResults, gckPath } = useGckPath()
  const gckSet = useMemo(() => new Set(gckPath), [gckPath])

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="h-8 text-xs text-[var(--color-text-secondary)] border-b border-[var(--color-border)]">
            <th className="w-6"></th>
            <th className="w-10 text-center">№</th>
            <th className="text-left px-2">Назначение</th>
            <th className="w-20 text-right px-2"><ColumnHint label="Q, Вт" hint={HYDRO_HINTS.Q} /></th>
            <th className="w-16 text-right px-2"><ColumnHint label="L, м" hint={HYDRO_HINTS.L} /></th>
            <th className="w-20 text-right px-2"><ColumnHint label="d_пр, мм" hint={HYDRO_HINTS.d_pr} /></th>
            <th className="w-20 text-right px-2"><ColumnHint label="v, м/с" hint={HYDRO_HINTS.v} /></th>
            <th className="w-20 text-right px-2"><ColumnHint label="ΔP, Па" hint={HYDRO_HINTS.deltaP} /></th>
            <th className="w-14"></th>
          </tr>
        </thead>
        <tbody>
          {segmentOrder.map((id, index) => (
            <SegmentRow
              key={id}
              segmentId={id}
              index={index}
              calcResult={segmentResults[id]}
              isInMainCircuit={gckSet.has(id)}
            />
          ))}
        </tbody>
      </table>
    </div>
  )
}
