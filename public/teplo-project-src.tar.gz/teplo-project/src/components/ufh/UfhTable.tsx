/**
 * UFH table — one row per room from projectStore.roomOrder.
 * Header: 7 columns per UI-SPEC (Помещение, F_тп, Покрытие, Труба, Шаг, q, warn).
 * Accordion rows are rendered by UfhLoopRow.
 */

import { useProjectStore } from '../../store/projectStore'
import { UfhLoopRow } from './UfhLoopRow'
import { ColumnHint } from '../ColumnHint'
import { UFH_HINTS } from '../hydraulics/glossary'

export function UfhTable() {
  const roomOrder = useProjectStore(s => s.roomOrder)
  const rooms = useProjectStore(s => s.rooms)

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="h-8 text-xs text-[var(--color-text-secondary)] border-b border-[var(--color-border)]">
            <th className="w-6 px-2"></th>
            <th className="text-left px-2">Помещение</th>
            <th className="w-20 text-right px-2"><ColumnHint label="F_тп, м²" hint={UFH_HINTS.F_tp} /></th>
            <th className="w-28 text-left px-2"><ColumnHint label="Покрытие" hint={UFH_HINTS.covering} /></th>
            <th className="w-28 text-left px-2"><ColumnHint label="Труба ТП" hint={UFH_HINTS.pipe} /></th>
            <th className="w-16 text-right px-2"><ColumnHint label="Шаг, см" hint={UFH_HINTS.step} /></th>
            <th className="w-20 text-right px-2"><ColumnHint label="q, Вт/м²" hint={UFH_HINTS.q_per_m2} /></th>
            <th className="w-6 text-center px-2" title="Предупреждения: нарушение норм t_пола или недостаточная мощность петли">!</th>
          </tr>
        </thead>
        <tbody>
          {roomOrder.map((roomId, index) => {
            const room = rooms[roomId]
            if (!room) return null
            return <UfhLoopRow key={roomId} room={room} index={index} />
          })}
        </tbody>
      </table>
    </div>
  )
}
