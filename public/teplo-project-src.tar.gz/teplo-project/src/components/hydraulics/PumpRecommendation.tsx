/**
 * PumpRecommendation — info-box рекомендации насоса по ГЦК.
 * Показывает ΔP_ГЦК и напор H. При отсутствии ГЦК — подсказка инженеру.
 */

import { CheckCircle } from 'lucide-react'
import { useGckPath } from './useGckPath'
import { useProjectStore } from '../../store/projectStore'
import { useCoolantCatalogStore } from '../../store/coolantCatalogStore'
import { recommendPump } from '../../engine/hydraulics'
import { ColumnHint } from '../ColumnHint'
import { HYDRO_HINTS } from './glossary'

export function PumpRecommendation() {
  const { gckPath, deltaPGckPa, totalFlowKgH } = useGckPath()
  const coolantId = useProjectStore(s => s.coolantId)
  const coolant = useCoolantCatalogStore(s => s.coolants[coolantId])

  if (gckPath.length === 0 || !coolant) {
    return (
      <div className="border border-[var(--color-border)] rounded bg-[var(--color-surface)] p-4">
        <h4 className="text-sm font-semibold mb-1">Рекомендация насоса</h4>
        <p className="text-sm text-[var(--color-text-secondary)]">
          Определите главное циркуляционное кольцо
        </p>
      </div>
    )
  }

  const pump = recommendPump(deltaPGckPa, coolant.rhoKgM3, totalFlowKgH)

  return (
    <div className="border border-[var(--color-border)] rounded bg-[var(--color-surface)] p-4">
      <h4 className="text-sm font-semibold mb-2">Рекомендация насоса</h4>
      <p className="font-mono text-base font-semibold">
        <ColumnHint label="ΔP_ГЦК" hint={HYDRO_HINTS.deltaP_gck} /> = {deltaPGckPa.toFixed(0)} Па →{' '}
        <ColumnHint label="H" hint={HYDRO_HINTS.H} /> = {pump.headM.toFixed(2)} м.вод.
      </p>
      <p className="flex items-center gap-1 text-xs text-[var(--color-success)] mt-1">
        <CheckCircle size={14} aria-hidden="true" /> Насос рекомендован
      </p>
    </div>
  )
}
