/**
 * Tests for SegmentRow accordion.
 * Covers: compact cells, expand/collapse, ГЦК highlight, editable fields,
 * Q readonly when equipmentId set, delete flow, KmsPicker open.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, fireEvent, render, screen } from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { SegmentRow } from './SegmentRow'
import { useSegmentStore } from '../../store/segmentStore'
import { useProjectStore } from '../../store/projectStore'
import { useCoolantCatalogStore } from '../../store/coolantCatalogStore'
import { usePipeCatalogStore } from '../../store/pipeCatalogStore'
import { useKmsCatalogStore } from '../../store/kmsCatalogStore'

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}))

let confirmMock: ReturnType<typeof vi.spyOn>

beforeEach(() => {
  act(() => {
    useSegmentStore.setState({ segments: {}, segmentOrder: [] })
    useCoolantCatalogStore.getState().resetToSeed()
    usePipeCatalogStore.getState().resetToSeed()
    useKmsCatalogStore.getState().resetToSeed()
    useProjectStore.setState({
      coolantId: 'water', tSupply: 80, tReturn: 60,
      pipeMaterialId: 'steel-vgp-dn20',
    })
  })
  confirmMock = vi.spyOn(window, 'confirm').mockReturnValue(true)
})

afterEach(() => {
  vi.restoreAllMocks()
})

function addTestSegment(overrides: {
  equipmentId?: string | null
  qOverride?: number | null
} = {}) {
  let id = ''
  act(() => {
    id = useSegmentStore.getState().addSegment({
      parentSegmentId: null,
      name: 'Тестовый участок',
      equipmentId: 'equipmentId' in overrides ? overrides.equipmentId ?? null : null,
      qOverride: 'qOverride' in overrides ? overrides.qOverride ?? null : 1500,
      lengthM: 10,
      pipeId: 'steel-vgp-dn20',
      dnMm: null,
      kmsCounts: {},
      velocityTargetMS: 0.6,
    })
  })
  return id
}

describe('SegmentRow', () => {
  it('renders compact cells: index, name input, L input', () => {
    const id = addTestSegment()
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    expect(screen.getByText('1')).toBeInTheDocument()
    expect(screen.getByDisplayValue('Тестовый участок')).toBeInTheDocument()
    expect(screen.getByDisplayValue('10')).toBeInTheDocument()
  })

  it('click toggles expand (aria-expanded)', () => {
    const id = addTestSegment()
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    const rows = document.querySelectorAll('tr[aria-expanded]')
    expect(rows.length).toBeGreaterThan(0)
    const summaryRow = rows[0]
    expect(summaryRow.getAttribute('aria-expanded')).toBe('false')
    fireEvent.click(summaryRow)
    expect(summaryRow.getAttribute('aria-expanded')).toBe('true')
  })

  it('ГЦК highlight class when isInMainCircuit=true', () => {
    const id = addTestSegment()
    const { container } = render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={true} />
      </tbody></table>
    )
    const rows = container.querySelectorAll('tr')
    const hasGckClass = Array.from(rows).some(r =>
      r.className.includes('gck-bg') || r.className.includes('gck-strip')
    )
    expect(hasGckClass).toBe(true)
  })

  it('no ГЦК class when isInMainCircuit=false', () => {
    const id = addTestSegment()
    const { container } = render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    const rows = container.querySelectorAll('tr')
    const hasGckClass = Array.from(rows).some(r =>
      r.className.includes('gck-bg') || r.className.includes('gck-strip')
    )
    expect(hasGckClass).toBe(false)
  })

  it('Q field is editable input when equipmentId is null', () => {
    const id = addTestSegment({ equipmentId: null, qOverride: 2000 })
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    const qInput = screen.getByLabelText('Q, Вт')
    expect(qInput).toBeInTheDocument()
    expect(qInput.tagName).toBe('INPUT')
  })

  it('Q field is readonly text when equipmentId is set', () => {
    const id = addTestSegment({ equipmentId: 'some-equip-id', qOverride: null })
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    // No Q input when equipmentId set — just a span
    expect(screen.queryByLabelText('Q, Вт')).not.toBeInTheDocument()
  })

  it('delete button calls window.confirm and deleteSegment on confirm', () => {
    const id = addTestSegment()
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    const deleteBtn = screen.getByRole('button', { name: /Удалить участок/i })
    fireEvent.click(deleteBtn)
    expect(confirmMock).toHaveBeenCalled()
    expect(useSegmentStore.getState().segmentOrder.includes(id)).toBe(false)
  })

  it('expanded row shows SegmentDetails with ΣКМС', () => {
    const id = addTestSegment()
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    const summaryRow = document.querySelector('tr[aria-expanded]')!
    fireEvent.click(summaryRow)
    expect(screen.getByText(/ΣКМС =/)).toBeInTheDocument()
  })

  it('expanded row shows "Изменить КМС" button that opens KmsPicker', () => {
    const id = addTestSegment()
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    const summaryRow = document.querySelector('tr[aria-expanded]')!
    fireEvent.click(summaryRow)
    const kmsBtn = screen.getByText('Изменить КМС →')
    fireEvent.click(kmsBtn)
    expect(screen.getByRole('dialog', { name: /Местные сопротивления/i })).toBeInTheDocument()
  })

  it('name blur updates segment name', () => {
    const id = addTestSegment()
    render(
      <table><tbody>
        <SegmentRow segmentId={id} index={0} calcResult={undefined} isInMainCircuit={false} />
      </tbody></table>
    )
    const nameInput = screen.getByDisplayValue('Тестовый участок')
    fireEvent.change(nameInput, { target: { value: 'Новое имя' } })
    fireEvent.blur(nameInput)
    expect(useSegmentStore.getState().segments[id]?.name).toBe('Новое имя')
  })
})
