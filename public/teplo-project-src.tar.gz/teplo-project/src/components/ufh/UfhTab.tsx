/**
 * UFH tab orchestrator: action bar (global tSupplyUfh/tReturnUfh) + rooms-driven table.
 * Empty state when no rooms — guides user to heat-loss tab.
 * Tab index 3 in TabBar.
 */

import { Thermometer } from 'lucide-react'
import { useProjectStore } from '../../store/projectStore'
import { UfhActionBar } from './UfhActionBar'
import { UfhTable } from './UfhTable'

export function UfhTab() {
  const roomOrder = useProjectStore(s => s.roomOrder)
  const hasRooms = roomOrder.length > 0

  return (
    <div className="mt-6 space-y-4">
      <UfhActionBar />

      {hasRooms ? (
        <UfhTable />
      ) : (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <Thermometer size={48} className="text-[var(--color-text-secondary)]" aria-hidden="true" />
          <h3 className="text-base font-semibold text-[var(--color-text-primary)]">
            Нет помещений
          </h3>
          <p className="text-sm text-[var(--color-text-secondary)]">
            Помещения появятся автоматически когда введёте данные в таб «Теплопотери»
          </p>
        </div>
      )}
    </div>
  )
}
