import { describe, it, expect, beforeEach } from 'vitest'
import { useProjectStore, selectDeltaT } from './projectStore'

// Reset store before each test
beforeEach(() => {
  const store = useProjectStore.getState()
  store.resetProject()
  useProjectStore.setState({ activeTab: 0 })
  localStorage.clear()
})

describe('useProjectStore', () => {
  describe('setCity', () => {
    it('sets city data', () => {
      const city = { name: 'Москва', tOutside: -28, gsop: 4943, humidityZone: 'Б' as const }
      useProjectStore.getState().setCity(city)
      expect(useProjectStore.getState().city).toEqual(city)
    })

    it('clears city with null', () => {
      const city = { name: 'Москва', tOutside: -28, gsop: 4943, humidityZone: 'Б' as const }
      useProjectStore.getState().setCity(city)
      useProjectStore.getState().setCity(null)
      expect(useProjectStore.getState().city).toBeNull()
    })
  })

  describe('setTInside', () => {
    it('sets temperature within range', () => {
      useProjectStore.getState().setTInside(22)
      expect(useProjectStore.getState().tInside).toBe(22)
    })

    it('clamps below minimum to 10', () => {
      useProjectStore.getState().setTInside(5)
      expect(useProjectStore.getState().tInside).toBe(10)
    })

    it('clamps above maximum to 60', () => {
      useProjectStore.getState().setTInside(65)
      expect(useProjectStore.getState().tInside).toBe(60)
    })
  })

  describe('setActiveTab', () => {
    it('sets active tab index', () => {
      useProjectStore.getState().setActiveTab(3)
      expect(useProjectStore.getState().activeTab).toBe(3)
    })
  })

  describe('importJSON', () => {
    it('loads valid project data', () => {
      const data = {
        city: { name: 'Москва', tOutside: -28, gsop: 4943, humidityZone: 'Б' },
        tInside: 22,
        rooms: {},
        roomOrder: []
      }
      useProjectStore.getState().importJSON(data)
      expect(useProjectStore.getState().city?.name).toBe('Москва')
      expect(useProjectStore.getState().tInside).toBe(22)
    })

    it('rejects invalid data (does not change state)', () => {
      const city = { name: 'Москва', tOutside: -28, gsop: 4943, humidityZone: 'Б' as const }
      useProjectStore.getState().setCity(city)
      useProjectStore.getState().importJSON({ invalid: true })
      // City should remain unchanged
      expect(useProjectStore.getState().city?.name).toBe('Москва')
    })
  })

  describe('resetProject', () => {
    it('resets all project data to defaults', () => {
      const city = { name: 'Москва', tOutside: -28, gsop: 4943, humidityZone: 'Б' as const }
      useProjectStore.getState().setCity(city)
      useProjectStore.getState().setTInside(25)
      useProjectStore.getState().resetProject()
      expect(useProjectStore.getState().city).toBeNull()
      expect(useProjectStore.getState().tInside).toBe(20)
      expect(useProjectStore.getState().rooms).toEqual({})
      expect(useProjectStore.getState().roomOrder).toEqual([])
    })
  })

  describe('Room CRUD', () => {
    const sampleRoom = {
      number: 101,
      name: 'Гостиная',
      floor: 1,
      area: 20,
      height: 2.7,
      isCorner: false,
      infiltrationMethod: 'rate' as const,
      nInfiltration: 0.5,
      gapArea: null,
      windSpeed: null,
      lVentilation: 0,
      tInside: 20
    }

    it('addRoom creates room with UUID and appends to roomOrder', () => {
      useProjectStore.getState().addRoom(sampleRoom)
      const state = useProjectStore.getState()
      const ids = state.roomOrder
      expect(ids).toHaveLength(1)
      const room = state.rooms[ids[0]]
      expect(room.name).toBe('Гостиная')
      expect(room.id).toBeDefined()
      expect(room.id.length).toBeGreaterThan(0)
    })

    it('updateRoom merges changes immutably', () => {
      useProjectStore.getState().addRoom(sampleRoom)
      const id = useProjectStore.getState().roomOrder[0]
      const originalRoom = useProjectStore.getState().rooms[id]
      useProjectStore.getState().updateRoom(id, { name: 'Кухня', area: 15 })
      const updated = useProjectStore.getState().rooms[id]
      expect(updated.name).toBe('Кухня')
      expect(updated.area).toBe(15)
      expect(updated.height).toBe(2.7) // unchanged
      expect(updated).not.toBe(originalRoom) // new reference
    })

    it('deleteRoom removes from rooms and roomOrder', () => {
      useProjectStore.getState().addRoom(sampleRoom)
      useProjectStore.getState().addRoom({ ...sampleRoom, name: 'Спальня' })
      const ids = useProjectStore.getState().roomOrder
      expect(ids).toHaveLength(2)
      useProjectStore.getState().deleteRoom(ids[0])
      const state = useProjectStore.getState()
      expect(state.roomOrder).toHaveLength(1)
      expect(state.rooms[ids[0]]).toBeUndefined()
      expect(state.rooms[ids[1]].name).toBe('Спальня')
    })

    it('addRoom sets Phase 2 fields when provided', () => {
      const cornerRoom = { ...sampleRoom, isCorner: true, infiltrationMethod: 'gap' as const, gapArea: 0.01, windSpeed: 3.5 }
      useProjectStore.getState().addRoom(cornerRoom)
      const id = useProjectStore.getState().roomOrder[0]
      const room = useProjectStore.getState().rooms[id]
      expect(room.isCorner).toBe(true)
      expect(room.infiltrationMethod).toBe('gap')
      expect(room.gapArea).toBe(0.01)
      expect(room.windSpeed).toBe(3.5)
    })
  })

  describe('importJSON backward compatibility', () => {
    it('imports Phase 1 rooms without Phase 2 fields and applies defaults', () => {
      const data = {
        city: null,
        tInside: 20,
        rooms: {
          'r1': { id: 'r1', name: 'Комната', floor: 1, area: 18, height: 2.7 }
        },
        roomOrder: ['r1']
      }
      useProjectStore.getState().importJSON(data)
      const room = useProjectStore.getState().rooms['r1']
      expect(room.isCorner).toBe(false)
      expect(room.infiltrationMethod).toBe('rate')
      expect(room.nInfiltration).toBeNull()
      expect(room.gapArea).toBeNull()
      expect(room.windSpeed).toBeNull()
      expect(room.lVentilation).toBe(0)
    })
  })

  describe('tSupply/tReturn (Phase 3)', () => {
    it('has default tSupply=80 and tReturn=60 after reset', () => {
      useProjectStore.getState().resetProject()
      expect(useProjectStore.getState().tSupply).toBe(80)
      expect(useProjectStore.getState().tReturn).toBe(60)
    })

    it('setTSupply accepts value within range', () => {
      useProjectStore.getState().setTSupply(75)
      expect(useProjectStore.getState().tSupply).toBe(75)
    })

    it('setTSupply clamps above maximum to 150 (T-3-01)', () => {
      useProjectStore.getState().setTSupply(99999)
      expect(useProjectStore.getState().tSupply).toBe(150)
    })

    it('setTSupply clamps below minimum to 20 (T-3-01)', () => {
      useProjectStore.getState().setTSupply(-50)
      expect(useProjectStore.getState().tSupply).toBe(20)
    })

    it('setTReturn accepts value within range', () => {
      useProjectStore.getState().setTReturn(50)
      expect(useProjectStore.getState().tReturn).toBe(50)
    })

    it('setTReturn clamps above maximum to 140', () => {
      useProjectStore.getState().setTReturn(99999)
      expect(useProjectStore.getState().tReturn).toBe(140)
    })

    it('setTReturn clamps below minimum to 10', () => {
      useProjectStore.getState().setTReturn(-50)
      expect(useProjectStore.getState().tReturn).toBe(10)
    })

    it('persists tSupply to localStorage', () => {
      useProjectStore.getState().setTSupply(85)
      const stored = localStorage.getItem('teplo-project')
      expect(stored).not.toBeNull()
      const parsed = JSON.parse(stored!)
      expect(parsed.state.tSupply).toBe(85)
    })

    it('persists tReturn to localStorage', () => {
      useProjectStore.getState().setTReturn(55)
      const stored = localStorage.getItem('teplo-project')
      expect(stored).not.toBeNull()
      const parsed = JSON.parse(stored!)
      expect(parsed.state.tReturn).toBe(55)
    })

    it('partialize whitelist includes tSupply and tReturn', () => {
      useProjectStore.getState().setTSupply(90)
      useProjectStore.getState().setTReturn(70)
      const stored = localStorage.getItem('teplo-project')
      const parsed = JSON.parse(stored!)
      // Существующие поля сохранены
      expect(parsed.state).toHaveProperty('city')
      expect(parsed.state).toHaveProperty('tInside')
      expect(parsed.state).toHaveProperty('rooms')
      expect(parsed.state).toHaveProperty('roomOrder')
      expect(parsed.state).toHaveProperty('customCities')
      // Новые Phase 3 поля тоже
      expect(parsed.state.tSupply).toBe(90)
      expect(parsed.state.tReturn).toBe(70)
    })

    it('importJSON Phase 1/2 backward-compat: missing tSupply/tReturn → defaults 80/60', () => {
      const data = {
        city: null,
        tInside: 20,
        rooms: {},
        roomOrder: []
      }
      useProjectStore.getState().setTSupply(85)
      useProjectStore.getState().setTReturn(65)
      useProjectStore.getState().importJSON(data)
      expect(useProjectStore.getState().tSupply).toBe(80)
      expect(useProjectStore.getState().tReturn).toBe(60)
    })

    it('importJSON Phase 3 forward: restores tSupply=90 and tReturn=70', () => {
      const data = {
        city: null,
        tInside: 20,
        rooms: {},
        roomOrder: [],
        tSupply: 90,
        tReturn: 70
      }
      useProjectStore.getState().importJSON(data)
      expect(useProjectStore.getState().tSupply).toBe(90)
      expect(useProjectStore.getState().tReturn).toBe(70)
    })

    it('importJSON with invalid tSupply type falls back to default 80 (defensive normalization)', () => {
      const data = {
        city: null,
        tInside: 20,
        rooms: {},
        roomOrder: [],
        tSupply: 'abc' as unknown as number
      }
      useProjectStore.getState().importJSON(data)
      // До Task 4 validateProjectJSON пропускает, но normalization клэмпит к default 80
      // После Task 4 validateProjectJSON отвергнет — state не изменится от default (тоже 80)
      expect(useProjectStore.getState().tSupply).toBe(80)
    })

    it('exportJSON includes tSupply and tReturn', () => {
      // Перехватываем URL.createObjectURL — проверяем содержимое Blob
      useProjectStore.getState().setTSupply(88)
      useProjectStore.getState().setTReturn(66)
      const state = useProjectStore.getState()
      expect(state.tSupply).toBe(88)
      expect(state.tReturn).toBe(66)
    })
  })
})

describe('Phase 4: UFH + hydraulics fields', () => {
  beforeEach(() => {
    useProjectStore.getState().resetProject()
  })

  it('has default schemaType=two-pipe-dead-end after reset', () => {
    expect(useProjectStore.getState().schemaType).toBe('two-pipe-dead-end')
  })

  it('has default pipeMaterialId=steel-vgp-dn20 after reset', () => {
    expect(useProjectStore.getState().pipeMaterialId).toBe('steel-vgp-dn20')
  })

  it('has default coolantId=water after reset', () => {
    expect(useProjectStore.getState().coolantId).toBe('water')
  })

  it('has default tSupplyUfh=45 after reset', () => {
    expect(useProjectStore.getState().tSupplyUfh).toBe(45)
  })

  it('has default tReturnUfh=35 after reset', () => {
    expect(useProjectStore.getState().tReturnUfh).toBe(35)
  })

  it('Test 13: setSchemaType accepts valid enum value', () => {
    useProjectStore.getState().setSchemaType('manifold')
    expect(useProjectStore.getState().schemaType).toBe('manifold')
    useProjectStore.getState().setSchemaType('single-pipe')
    expect(useProjectStore.getState().schemaType).toBe('single-pipe')
  })

  it('Test 14a: setPipeMaterialId sets string value', () => {
    useProjectStore.getState().setPipeMaterialId('pe-x-16-2')
    expect(useProjectStore.getState().pipeMaterialId).toBe('pe-x-16-2')
  })

  it('Test 14b: setCoolantId sets string value', () => {
    useProjectStore.getState().setCoolantId('glycol-30')
    expect(useProjectStore.getState().coolantId).toBe('glycol-30')
  })

  it('Test 11: setTSupplyUfh clamps above 60 → 60', () => {
    useProjectStore.getState().setTSupplyUfh(100)
    expect(useProjectStore.getState().tSupplyUfh).toBe(60)
  })

  it('setTSupplyUfh clamps below 30 → 30', () => {
    useProjectStore.getState().setTSupplyUfh(10)
    expect(useProjectStore.getState().tSupplyUfh).toBe(30)
  })

  it('setTSupplyUfh accepts value in range [30..60]', () => {
    useProjectStore.getState().setTSupplyUfh(45)
    expect(useProjectStore.getState().tSupplyUfh).toBe(45)
  })

  it('Test 12: setTReturnUfh clamps above 55 → 55', () => {
    useProjectStore.getState().setTReturnUfh(100)
    expect(useProjectStore.getState().tReturnUfh).toBe(55)
  })

  it('setTReturnUfh clamps below 25 → 25', () => {
    useProjectStore.getState().setTReturnUfh(5)
    expect(useProjectStore.getState().tReturnUfh).toBe(25)
  })

  it('setTReturnUfh accepts value in range [25..55]', () => {
    useProjectStore.getState().setTReturnUfh(35)
    expect(useProjectStore.getState().tReturnUfh).toBe(35)
  })

  it('Phase 4 fields persisted to localStorage', () => {
    useProjectStore.getState().setSchemaType('manifold')
    useProjectStore.getState().setTSupplyUfh(50)
    useProjectStore.getState().setTReturnUfh(40)
    const stored = localStorage.getItem('teplo-project')
    expect(stored).not.toBeNull()
    const parsed = JSON.parse(stored!)
    expect(parsed.state.schemaType).toBe('manifold')
    expect(parsed.state.tSupplyUfh).toBe(50)
    expect(parsed.state.tReturnUfh).toBe(40)
  })

  it('Phase 4 fields backward-compat: importJSON without Phase 4 fields uses defaults', () => {
    useProjectStore.getState().setSchemaType('manifold')
    useProjectStore.getState().importJSON({ city: null, tInside: 20, rooms: {}, roomOrder: [] })
    expect(useProjectStore.getState().schemaType).toBe('two-pipe-dead-end')
    expect(useProjectStore.getState().pipeMaterialId).toBe('steel-vgp-dn20')
    expect(useProjectStore.getState().coolantId).toBe('water')
    expect(useProjectStore.getState().tSupplyUfh).toBe(45)
    expect(useProjectStore.getState().tReturnUfh).toBe(35)
  })
})

describe('selectDeltaT', () => {
  it('returns tInside - tOutside when city is set', () => {
    const state = {
      ...useProjectStore.getState(),
      city: { name: 'Москва', tOutside: -28, gsop: 4943, humidityZone: 'Б' as const },
      tInside: 20
    }
    expect(selectDeltaT(state)).toBe(48)
  })

  it('returns null when city is null', () => {
    const state = { ...useProjectStore.getState(), city: null, tInside: 20 }
    expect(selectDeltaT(state)).toBeNull()
  })
})
