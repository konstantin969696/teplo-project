/**
 * Tests for HydraulicsActionBar.
 * Covers: render (3 selects + 5 buttons), schema change, coolant change,
 * addSegment, autogenerate, catalog modal open/close.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, fireEvent, render, screen } from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { HydraulicsActionBar } from './HydraulicsActionBar'
import { useProjectStore } from '../../store/projectStore'
import { useSegmentStore } from '../../store/segmentStore'
import { useCoolantCatalogStore } from '../../store/coolantCatalogStore'
import { usePipeCatalogStore } from '../../store/pipeCatalogStore'
import { useEquipmentStore } from '../../store/equipmentStore'

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}))

beforeEach(() => {
  act(() => {
    useSegmentStore.setState({ segments: {}, segmentOrder: [] })
    useCoolantCatalogStore.getState().resetToSeed()
    usePipeCatalogStore.getState().resetToSeed()
    useEquipmentStore.setState({ equipment: {}, equipmentOrder: [] })
    useProjectStore.setState({
      schemaType: 'two-pipe-dead-end',
      coolantId: 'water',
      pipeMaterialId: 'steel-vgp-dn20',
    })
  })
})

afterEach(() => {
  vi.restoreAllMocks()
})

describe('HydraulicsActionBar', () => {
  it('renders schema, coolant and pipe type selects', () => {
    render(<HydraulicsActionBar />)
    expect(screen.getByLabelText('Схема отопления')).toBeInTheDocument()
    expect(screen.getByLabelText('Теплоноситель')).toBeInTheDocument()
    expect(screen.getByLabelText('Тип труб')).toBeInTheDocument()
  })

  it('renders "Добавить участок" and "Автогенерация скелета" buttons', () => {
    render(<HydraulicsActionBar />)
    expect(screen.getByRole('button', { name: /Добавить участок/i })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /Автогенерация скелета/i })).toBeInTheDocument()
  })

  it('renders three catalog buttons', () => {
    render(<HydraulicsActionBar />)
    expect(screen.getByRole('button', { name: /Каталог труб/i })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /Каталог КМС/i })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /Каталог теплоносителей/i })).toBeInTheDocument()
  })

  it('schema change updates projectStore.schemaType', () => {
    render(<HydraulicsActionBar />)
    const select = screen.getByLabelText('Схема отопления')
    fireEvent.change(select, { target: { value: 'manifold' } })
    expect(useProjectStore.getState().schemaType).toBe('manifold')
  })

  it('coolant change calls setCoolantId', () => {
    render(<HydraulicsActionBar />)
    const select = screen.getByLabelText('Теплоноситель')
    // Get first available option value
    const firstOption = select.querySelector('option')
    if (firstOption) {
      fireEvent.change(select, { target: { value: firstOption.value } })
      expect(useProjectStore.getState().coolantId).toBe(firstOption.value)
    }
  })

  it('"Добавить участок" calls addSegment', () => {
    render(<HydraulicsActionBar />)
    const btn = screen.getByRole('button', { name: /Добавить участок/i })
    fireEvent.click(btn)
    const { segmentOrder, segments } = useSegmentStore.getState()
    expect(segmentOrder.length).toBe(1)
    expect(Object.keys(segments).length).toBe(1)
  })

  it('"Автогенерация скелета" is disabled when no equipment', () => {
    render(<HydraulicsActionBar />)
    const btn = screen.getByRole('button', { name: /Автогенерация скелета/i })
    expect(btn).toBeDisabled()
  })

  it('"Автогенерация скелета" calls bulkAddSegments when equipment exists', () => {
    act(() => {
      useEquipmentStore.setState({
        equipment: {
          'eq-1': {
            id: 'eq-1', roomId: 'r1', kind: 'bimetal', catalogModelId: null,
            connection: 'side', installation: 'open', panelType: null,
            panelHeightMm: null, panelLengthMm: null, sectionsOverride: null,
            convectorLengthMm: null, manualQNominal: null, manualNExponent: null,
          }
        },
        equipmentOrder: ['eq-1']
      })
    })
    render(<HydraulicsActionBar />)
    const btn = screen.getByRole('button', { name: /Автогенерация скелета/i })
    expect(btn).not.toBeDisabled()
    fireEvent.click(btn)
    const { segmentOrder } = useSegmentStore.getState()
    // magistral + 1 equipment = 2
    expect(segmentOrder.length).toBe(2)
  })

  it('opens PipeCatalogModal on "Каталог труб…" click', () => {
    render(<HydraulicsActionBar />)
    fireEvent.click(screen.getByRole('button', { name: /Каталог труб/i }))
    expect(screen.getByRole('dialog', { name: /Каталог труб/i })).toBeInTheDocument()
  })

  it('opens KmsCatalogModal on "Каталог КМС…" click', () => {
    render(<HydraulicsActionBar />)
    fireEvent.click(screen.getByRole('button', { name: /Каталог КМС/i }))
    expect(screen.getByRole('dialog', { name: /Справочник КМС/i })).toBeInTheDocument()
  })

  it('opens CoolantCatalogModal on "Каталог теплоносителей…" click', () => {
    render(<HydraulicsActionBar />)
    fireEvent.click(screen.getByRole('button', { name: /Каталог теплоносителей/i }))
    expect(screen.getByRole('dialog', { name: /Каталог теплоносителей/i })).toBeInTheDocument()
  })

  it('PipeCatalogModal closes on Escape', () => {
    render(<HydraulicsActionBar />)
    fireEvent.click(screen.getByRole('button', { name: /Каталог труб/i }))
    expect(screen.getByRole('dialog', { name: /Каталог труб/i })).toBeInTheDocument()
    fireEvent.keyDown(document, { key: 'Escape' })
    expect(screen.queryByRole('dialog', { name: /Каталог труб/i })).not.toBeInTheDocument()
  })
})
