/**
 * useGckPath — мемоизированный hook для расчёта ГЦК и результатов по всем участкам.
 * Зависимости: [segments, tSupply, tReturn, coolantId, coolants, pipes, kmsCatalog, equipment].
 * Pitfall 7 mitigation: useMemo предотвращает лишние пересчёты при ре-рендерах.
 */

import { useMemo } from 'react'
import { useShallow } from 'zustand/react/shallow'
import {
  findMainCircuit,
  calculateSegment,
  calculateSegmentQ,
  recommendPump,
  type SegmentCalcResult,
} from '../../engine/hydraulics'
import { useSegmentStore } from '../../store/segmentStore'
import { useProjectStore } from '../../store/projectStore'
import { usePipeCatalogStore } from '../../store/pipeCatalogStore'
import { useKmsCatalogStore } from '../../store/kmsCatalogStore'
import { useCoolantCatalogStore } from '../../store/coolantCatalogStore'
import { useEquipmentStore } from '../../store/equipmentStore'
import type { SegmentNode } from '../../types/hydraulics'

export interface GckComputationResult {
  readonly segmentResults: Readonly<Record<string, SegmentCalcResult>>
  readonly gckPath: readonly string[]
  readonly deltaPGckPa: number
  readonly totalFlowKgH: number
}

const EMPTY_RESULT: GckComputationResult = {
  segmentResults: {},
  gckPath: [],
  deltaPGckPa: 0,
  totalFlowKgH: 0,
}

export function useGckPath(): GckComputationResult {
  const segments = useSegmentStore(s => s.segments)
  const tSupply = useProjectStore(s => s.tSupply)
  const tReturn = useProjectStore(s => s.tReturn)
  const coolantId = useProjectStore(s => s.coolantId)
  const coolants = useCoolantCatalogStore(s => s.coolants)
  const pipes = usePipeCatalogStore(s => s.pipes)
  const kmsCatalog = useKmsCatalogStore(useShallow(s => Object.values(s.elements)))
  const equipment = useEquipmentStore(s => s.equipment)

  return useMemo(() => {
    const coolant = coolants[coolantId]
    if (!coolant) return EMPTY_RESULT

    const deltaT = Math.max(1, tSupply - tReturn)

    // equipmentQMap: id → расчётный Q из Phase 3
    const equipmentQMap: Record<string, number> = {}
    for (const [id, eq] of Object.entries(equipment)) {
      // Phase 3 stores calculated Q in equipment.calculated?.Q
      // Fallback to 0 if not yet calculated
      const calc = (eq as { calculated?: { Q?: number } }).calculated
      equipmentQMap[id] = calc?.Q ?? 0
    }

    const pipeArr = Object.values(pipes)
    const segmentResults: Record<string, SegmentCalcResult> = {}

    for (const [id, seg] of Object.entries(segments)) {
      const q = calculateSegmentQ(id, segments, equipmentQMap)
      segmentResults[id] = calculateSegment(seg, q, coolant, deltaT, pipeArr, kmsCatalog)
    }

    // Построить граф узлов для findMainCircuit
    const childrenMap: Record<string, string[]> = {}
    for (const [id, seg] of Object.entries(segments)) {
      if (seg.parentSegmentId !== null) {
        if (!childrenMap[seg.parentSegmentId]) childrenMap[seg.parentSegmentId] = []
        childrenMap[seg.parentSegmentId].push(id)
      }
    }

    const nodes: SegmentNode[] = Object.entries(segments).map(([id, seg]) => ({
      id,
      parentId: seg.parentSegmentId,
      children: childrenMap[id] ?? [],
      deltaP: segmentResults[id]?.deltaPTotalPa ?? 0,
    }))

    const gckPath = findMainCircuit(nodes)
    const deltaPGckPa = gckPath.reduce(
      (sum, id) => sum + (segmentResults[id]?.deltaPTotalPa ?? 0),
      0
    )

    // Суммарный расход через насос — сумма расходов корневых сегментов
    const rootSegments = Object.values(segments).filter(s => s.parentSegmentId === null)
    const totalFlowKgH = rootSegments.reduce(
      (sum, s) => sum + (segmentResults[s.id]?.flowKgH ?? 0),
      0
    )

    return { segmentResults, gckPath, deltaPGckPa, totalFlowKgH }
  }, [segments, tSupply, tReturn, coolantId, coolants, pipes, kmsCatalog, equipment])
}

// Re-export for convenience
export { recommendPump }
