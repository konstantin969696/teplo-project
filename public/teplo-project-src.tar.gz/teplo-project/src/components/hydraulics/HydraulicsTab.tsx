/**
 * HydraulicsTab — orchestrator таба «Гидравлика» (index 2).
 * Паттерн Phase 3 EquipmentTab (P9 orchestrator).
 * Рендерит HydraulicsActionBar всегда + условно SegmentTable/PumpRecommendation/BalancingBlock
 * или empty-state когда участков нет.
 */

import { useSegmentStore } from '../../store/segmentStore'
import { HydraulicsActionBar } from './HydraulicsActionBar'
import { SegmentTable } from './SegmentTable'
import { PumpRecommendation } from './PumpRecommendation'
import { BalancingBlock } from './BalancingBlock'

export function HydraulicsTab() {
  const segmentOrder = useSegmentStore(s => s.segmentOrder)
  const hasSegments = segmentOrder.length > 0

  return (
    <div className="mt-6 space-y-6">
      <HydraulicsActionBar />

      {hasSegments ? (
        <>
          <SegmentTable />
          <PumpRecommendation />
          <BalancingBlock />
        </>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <h3 className="text-base font-semibold text-[var(--color-text-primary)]">
            Нет участков
          </h3>
          <p className="text-sm text-[var(--color-text-secondary)] text-center max-w-md">
            Нажмите «Добавить участок» или дождитесь автогенерации из таба «Приборы»
          </p>
        </div>
      )}
    </div>
  )
}
