/**
 * Tests for UfhActionBar component.
 * Covers: inputs with correct defaults/ranges, clamp behavior, catalog modal.
 */

import '@testing-library/jest-dom/vitest'
import { describe, it, expect, beforeEach, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { UfhActionBar } from './UfhActionBar'
import { useProjectStore } from '../../store/projectStore'

// Mock CoolantCatalogModal
vi.mock('../hydraulics/CoolantCatalogModal', () => ({
  CoolantCatalogModal: ({ open }: { open: boolean }) =>
    open ? <div data-testid="coolant-catalog-modal">Modal</div> : null,
}))

describe('UfhActionBar', () => {
  beforeEach(() => {
    useProjectStore.setState({ tSupplyUfh: 45, tReturnUfh: 35 })
  })

  it('Test 5 (UfhActionBar inputs): два number input с default 45/35', () => {
    render(<UfhActionBar />)
    const supplyInput = screen.getByLabelText(/подача ТП/i)
    const returnInput = screen.getByLabelText(/обратк/i)
    expect(supplyInput).toHaveValue(45)
    expect(returnInput).toHaveValue(35)
  })

  it('Test 5b (UfhActionBar inputs): range supply [30..60]', () => {
    render(<UfhActionBar />)
    const supplyInput = screen.getByLabelText(/подача ТП/i)
    expect(supplyInput).toHaveAttribute('min', '30')
    expect(supplyInput).toHaveAttribute('max', '60')
  })

  it('Test 5c (UfhActionBar inputs): range return [25..55]', () => {
    render(<UfhActionBar />)
    const returnInput = screen.getByLabelText(/обратк/i)
    expect(returnInput).toHaveAttribute('min', '25')
    expect(returnInput).toHaveAttribute('max', '55')
  })

  it('Test 6 (UfhActionBar setter clamp): ввод 70 → clamp до 60', () => {
    render(<UfhActionBar />)
    const supplyInput = screen.getByLabelText(/подача ТП/i)
    fireEvent.change(supplyInput, { target: { value: '70' } })
    expect(useProjectStore.getState().tSupplyUfh).toBe(60)
  })

  it('Test 6b (UfhActionBar setter clamp): ввод 10 для обратки → clamp до 25', () => {
    render(<UfhActionBar />)
    const returnInput = screen.getByLabelText(/обратк/i)
    fireEvent.change(returnInput, { target: { value: '10' } })
    expect(useProjectStore.getState().tReturnUfh).toBe(25)
  })

  it('Test 7 (UfhActionBar catalog button): click → CoolantCatalogModal open=true', () => {
    render(<UfhActionBar />)
    expect(screen.queryByTestId('coolant-catalog-modal')).not.toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: /каталог теплоносителей/i }))
    expect(screen.getByTestId('coolant-catalog-modal')).toBeInTheDocument()
  })

  it('Test 7b (UfhActionBar): валидное значение 50 принимается', () => {
    render(<UfhActionBar />)
    const supplyInput = screen.getByLabelText(/подача ТП/i)
    fireEvent.change(supplyInput, { target: { value: '50' } })
    expect(useProjectStore.getState().tSupplyUfh).toBe(50)
  })
})
