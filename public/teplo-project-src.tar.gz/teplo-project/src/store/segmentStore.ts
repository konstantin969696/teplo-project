/**
 * Segment store — normalized CRUD для участков гидравлики.
 * Pattern: Phase 2/3 (equipmentStore + enclosureStore orphan handling).
 * Persist key: 'teplo-segments'. Persists: segments + segmentOrder.
 *
 * Threat mitigation:
 *   T-04-08: IDs generated via uuid(), never accepted from external input.
 *   Input from UI (not raw JSON) — no prototype pollution path here.
 *
 * Decisions:
 *   D-03: segmentOrder defines display numbering order.
 *   D-02: equipmentId optional — null for magistral segments.
 */

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { safeStorage } from './safeStorage'
import { uuid } from './uuid'
import type { Segment, KmsCounts } from '../types/hydraulics'

export interface SegmentState {
  readonly segments: Record<string, Segment>
  readonly segmentOrder: readonly string[]
  addSegment: (seg: Omit<Segment, 'id'>) => string
  updateSegment: (id: string, changes: Partial<Omit<Segment, 'id'>>) => void
  deleteSegment: (id: string) => void
  deleteByEquipmentId: (equipmentId: string) => void
  reorderSegments: (newOrder: readonly string[]) => void
  updateKmsCount: (segmentId: string, kmsId: string, count: number) => void
  clearAllSegments: () => void
  bulkAddSegments: (segs: ReadonlyArray<Omit<Segment, 'id'>>) => readonly string[]
}

export const useSegmentStore = create<SegmentState>()(
  persist(
    (set) => ({
      segments: {},
      segmentOrder: [],

      addSegment: (seg: Omit<Segment, 'id'>): string => {
        const id = uuid()
        set(state => ({
          segments: { ...state.segments, [id]: { ...seg, id } as Segment },
          segmentOrder: [...state.segmentOrder, id]
        }))
        return id
      },

      updateSegment: (id: string, changes: Partial<Omit<Segment, 'id'>>) => set(state => {
        if (!state.segments[id]) return state
        return {
          segments: {
            ...state.segments,
            [id]: { ...state.segments[id], ...changes } as Segment
          }
        }
      }),

      deleteSegment: (id: string) => set(state => {
        const { [id]: _removed, ...rest } = state.segments
        // Orphan handling: children with parentSegmentId=id → parentSegmentId=null
        const segments: Record<string, Segment> = {}
        for (const [sid, seg] of Object.entries(rest)) {
          segments[sid] = seg.parentSegmentId === id
            ? { ...seg, parentSegmentId: null }
            : seg
        }
        return {
          segments,
          segmentOrder: state.segmentOrder.filter(sid => sid !== id)
        }
      }),

      deleteByEquipmentId: (equipmentId: string) => set(state => {
        const toRemove = new Set(
          Object.values(state.segments)
            .filter(s => s.equipmentId === equipmentId)
            .map(s => s.id)
        )
        if (toRemove.size === 0) return state
        const segments: Record<string, Segment> = {}
        for (const [sid, seg] of Object.entries(state.segments)) {
          if (toRemove.has(sid)) continue
          segments[sid] = toRemove.has(seg.parentSegmentId ?? '')
            ? { ...seg, parentSegmentId: null }
            : seg
        }
        return {
          segments,
          segmentOrder: state.segmentOrder.filter(sid => !toRemove.has(sid))
        }
      }),

      reorderSegments: (newOrder: readonly string[]) => set({ segmentOrder: [...newOrder] }),

      updateKmsCount: (segmentId: string, kmsId: string, count: number) => set(state => {
        const seg = state.segments[segmentId]
        if (!seg) return state
        const newCounts: KmsCounts = count > 0
          ? { ...seg.kmsCounts, [kmsId]: count }
          : Object.fromEntries(Object.entries(seg.kmsCounts).filter(([k]) => k !== kmsId))
        return {
          segments: {
            ...state.segments,
            [segmentId]: { ...seg, kmsCounts: newCounts }
          }
        }
      }),

      clearAllSegments: () => set({ segments: {}, segmentOrder: [] }),

      bulkAddSegments: (segs: ReadonlyArray<Omit<Segment, 'id'>>): readonly string[] => {
        const newIds: string[] = []
        set(state => {
          const nextSegments = { ...state.segments }
          for (const s of segs) {
            const id = uuid()
            nextSegments[id] = { ...s, id } as Segment
            newIds.push(id)
          }
          return {
            segments: nextSegments,
            segmentOrder: [...state.segmentOrder, ...newIds]
          }
        })
        return newIds
      }
    }),
    {
      name: 'teplo-segments',
      storage: createJSONStorage(() => safeStorage),
      partialize: (state) => ({
        segments: state.segments,
        segmentOrder: state.segmentOrder
      } as unknown as SegmentState),
      onRehydrateStorage: () => (_state, error) => {
        if (error) {
          console.error('Segment rehydration failed:', error)
        }
      }
    }
  )
)

/** Selector — returns segments with given parentId in display order. */
export const selectSegmentsByParent = (parentId: string | null) =>
  (state: SegmentState): readonly Segment[] =>
    state.segmentOrder
      .map(id => state.segments[id])
      .filter((s): s is Segment => s !== undefined && s.parentSegmentId === parentId)
