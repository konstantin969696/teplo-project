/**
 * Equipment row — ONE row per ROOM (not per equipment).
 * Summary cells: chevron | name | Q_пом | N приборов | Σ Q_факт | запас% | +add.
 * Expanded: renders EquipmentSubTable with all devices for this room.
 * Multi-equipment is first-class: rooms can have 2+ radiators, mix types,
 * combine radiator + underfloor convector, etc. Σ Q_факт compared to Q_пом.
 * Q_пом DERIVED via calculateRoomTotals (D-07) — never stored.
 */

import { useCallback, useMemo, useState } from 'react'
import { ChevronRight, Plus } from 'lucide-react'
import { useShallow } from 'zustand/react/shallow'
import type { Equipment, Room } from '../../types/project'
import { useProjectStore } from '../../store/projectStore'
import { useEnclosureStore } from '../../store/enclosureStore'
import { useEquipmentStore } from '../../store/equipmentStore'
import { useCatalogStore } from '../../store/catalogStore'
import { useUfhLoopStore, selectLoopByRoom } from '../../store/ufhLoopStore'
import { calculateRoomTotals } from '../../engine/heatLoss'
import { calculateLMTD } from '../../engine/equipment'
import { calculateHeatFlux } from '../../engine/ufh'
import { deriveEquipmentQActual, formatSurplusPct } from './equipment-help'
import { EquipmentSubTable } from './EquipmentSubTable'

interface EquipmentRowProps {
  room: Room
  index: number
}

export function EquipmentRow({ room, index }: EquipmentRowProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  const tOutside = useProjectStore(s => s.city?.tOutside ?? null)
  const tSupply = useProjectStore(s => s.tSupply)
  const tReturn = useProjectStore(s => s.tReturn)
  const tSupplyUfh = useProjectStore(s => s.tSupplyUfh)
  const tReturnUfh = useProjectStore(s => s.tReturnUfh)
  const ufhLoop = useUfhLoopStore(useShallow(selectLoopByRoom(room.id)))

  const enclosures = useEnclosureStore(
    useShallow(state => {
      const out: typeof state.enclosures[string][] = []
      for (const id of state.enclosureOrder) {
        const e = state.enclosures[id]
        if (e && e.roomId === room.id) out.push(e)
      }
      return out
    })
  )

  const equipmentList = useEquipmentStore(
    useShallow(state => {
      const out: typeof state.equipment[string][] = []
      for (const id of state.equipmentOrder) {
        const e = state.equipment[id]
        if (e && e.roomId === room.id) out.push(e)
      }
      return out
    })
  )

  // Catalog lookup — subscribe to the whole models map so that updates to any
  // referenced catalog entry re-render this row. Cheap because models changes
  // are rare after load.
  const modelsMap = useCatalogStore(s => s.models)

  const qUfhActive = useMemo(() => {
    if (!ufhLoop || !ufhLoop.enabled) return 0
    const q = calculateHeatFlux(tSupplyUfh, tReturnUfh, room.tInside, ufhLoop.covering)
    return q * ufhLoop.activeAreaM2
  }, [ufhLoop, tSupplyUfh, tReturnUfh, room.tInside])

  const qRequired = useMemo(() => {
    if (tOutside === null) return null
    const deltaT = room.tInside - tOutside
    if (deltaT <= 0) return null
    const qRoom = calculateRoomTotals(enclosures, room, deltaT).qTotal
    return Math.max(0, qRoom - qUfhActive)  // D-06: UFH даёт максимум, остаток → радиатор
  }, [enclosures, room, tOutside, qUfhActive])

  const lmtd = useMemo(
    () => calculateLMTD(tSupply, tReturn, room.tInside),
    [tSupply, tReturn, room.tInside]
  )

  // Σ Q_факт across all equipment in the room
  const qActualSum = useMemo(() => {
    if (equipmentList.length === 0 || qRequired === null || lmtd <= 0) return null
    const target = qRequired / equipmentList.length
    let sum = 0
    let anyValid = false
    for (const eq of equipmentList) {
      const model = eq.catalogModelId ? modelsMap[eq.catalogModelId] ?? null : null
      const { qActual } = deriveEquipmentQActual(eq, model, target, lmtd)
      if (qActual !== null) {
        sum += qActual
        anyValid = true
      }
    }
    return anyValid ? sum : null
  }, [equipmentList, qRequired, lmtd, modelsMap])

  const handleAddFirstEquipment = useCallback((e: React.MouseEvent) => {
    e.stopPropagation()
    useEquipmentStore.getState().addEquipment({
      roomId: room.id,
      kind: 'bimetal',
      catalogModelId: null,
      connection: 'side',
      installation: 'open',
      panelType: null,
      panelHeightMm: null,
      panelLengthMm: null,
      sectionsOverride: null,
      convectorLengthMm: null,
      manualQNominal: null,
      manualNExponent: null,
    })
    setIsExpanded(true)
  }, [room.id])

  const toggleExpand = useCallback(() => setIsExpanded(prev => !prev), [])

  const zebraClass = index % 2 === 0 ? 'bg-[var(--color-bg)]' : 'bg-[var(--color-surface)]'
  const isEmpty = equipmentList.length === 0
  const insufficient = qRequired !== null && qActualSum !== null && qActualSum < qRequired

  return (
    <>
      <tr
        className={`h-10 cursor-pointer hover:bg-[var(--color-surface)] ${zebraClass}`}
        onClick={toggleExpand}
        aria-expanded={isExpanded}
      >
        <td className="px-2 py-1">
          <ChevronRight
            size={14}
            className={`transition-transform duration-200 text-[var(--color-text-secondary)] ${isExpanded ? 'rotate-90' : ''}`}
            aria-hidden="true"
          />
        </td>
        <td className="px-2 py-1 text-[var(--color-text-primary)]">
          {room.name || `Комната ${index + 1}`}
        </td>
        <td
          className="px-2 py-1 text-right font-mono text-[var(--color-text-primary)]"
          data-testid="q-required"
        >
          {qRequired !== null ? Math.round(qRequired) : '—'}
        </td>
        <td className="px-2 py-1 text-center font-mono text-[var(--color-text-secondary)]" data-testid="equipment-count">
          {isEmpty ? '—' : equipmentList.length}
        </td>
        <td
          className="px-2 py-1 text-right font-mono font-semibold text-[var(--color-text-primary)]"
          data-testid="q-actual-sum"
        >
          {qActualSum !== null ? Math.round(qActualSum) : '—'}
        </td>
        <td className="px-2 py-1 text-right font-mono" data-testid="surplus-pct">
          {qActualSum !== null && qRequired !== null ? (
            <span className={insufficient ? 'text-[var(--color-destructive)]' : 'text-[var(--color-text-primary)]'}>
              {formatSurplusPct(qActualSum, qRequired)}
            </span>
          ) : '—'}
        </td>
        <td className="px-2 py-1">
          <button
            onClick={handleAddFirstEquipment}
            className="p-1 text-[var(--color-accent)] hover:text-[var(--color-accent-hover)] transition-colors"
            aria-label={`Добавить прибор для ${room.name || 'помещение'}`}
            title={isEmpty ? 'Добавить прибор' : 'Добавить ещё прибор'}
          >
            <Plus size={14} aria-hidden="true" />
          </button>
        </td>
      </tr>

      {isExpanded && (
        <tr>
          <td colSpan={7} className="p-0">
            <EquipmentSubTable
              room={room}
              qRequired={qRequired}
              tSupply={tSupply}
              tReturn={tReturn}
            />
          </td>
        </tr>
      )}
    </>
  )
}

/** Convenience re-export so tests/imports continue to resolve. */
export type { Equipment }
