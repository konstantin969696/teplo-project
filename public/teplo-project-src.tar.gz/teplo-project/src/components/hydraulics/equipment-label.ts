/**
 * Builds human-readable labels for equipment items used in the hydraulics
 * segment selector. Number is the 1-based index of the equipment within its
 * room (in equipmentOrder), so users see "Пр-1, Пр-2" per room.
 */

import type { Equipment, Room } from '../../types/project'

export interface EquipmentLabelOption {
  readonly id: string
  readonly label: string
}

export function buildEquipmentLabel(
  equipment: Equipment,
  equipmentOrder: readonly string[],
  equipmentMap: Readonly<Record<string, Equipment>>,
  rooms: Readonly<Record<string, Room>>
): string {
  const room = rooms[equipment.roomId]
  const roomPart = room
    ? `${room.number ? `пом. ${room.number} ` : ''}${room.name}`.trim()
    : 'без комнаты'

  const idxInRoom = equipmentOrder
    .filter(eid => equipmentMap[eid]?.roomId === equipment.roomId)
    .indexOf(equipment.id)
  const num = idxInRoom >= 0 ? idxInRoom + 1 : 1

  return `Пр-${num} · ${roomPart}`
}

export function buildEquipmentOptions(
  equipmentOrder: readonly string[],
  equipmentMap: Readonly<Record<string, Equipment>>,
  rooms: Readonly<Record<string, Room>>
): readonly EquipmentLabelOption[] {
  return equipmentOrder
    .map(id => equipmentMap[id])
    .filter((eq): eq is Equipment => Boolean(eq))
    .map(eq => ({
      id: eq.id,
      label: buildEquipmentLabel(eq, equipmentOrder, equipmentMap, rooms),
    }))
}
