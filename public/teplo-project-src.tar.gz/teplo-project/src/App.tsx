/**
 * Application shell: header, tab bar, content panels, toast provider.
 * Tab 0 (Теплопотери) renders ClimateCard + HeatLossTab; tab 1 (Приборы отопления)
 * renders EquipmentTab; tab 2 (Гидравлика) renders HydraulicsTab;
 * tab 3 (Тёплый пол) renders UfhTab; tab 4 shows EmptyTabState.
 */

import { Toaster } from 'sonner'
import { AppHeader } from './components/layout/AppHeader'
import { TabBar } from './components/layout/TabBar'
import { ClimateCard } from './components/climate/ClimateCard'
import { EmptyTabState } from './components/ui/EmptyTabState'
import { HeatLossTab } from './components/heatLoss/HeatLossTab'
import { EquipmentTab } from './components/equipment/EquipmentTab'
import { HydraulicsTab } from './components/hydraulics/HydraulicsTab'
import { UfhTab } from './components/ufh/UfhTab'
import { useProjectStore } from './store/projectStore'

const TAB_NAMES = ['Теплопотери', 'Приборы отопления', 'Гидравлика', 'Тёплый пол', 'Сводка'] as const

export function App() {
  const activeTab = useProjectStore(s => s.activeTab)

  return (
    <div className="min-h-screen bg-[var(--color-bg)] text-[var(--color-text-primary)]">
      <AppHeader />
      <TabBar />
      <main className="max-w-[1280px] mx-auto px-4 sm:px-6 py-4">
        {TAB_NAMES.map((name, i) => (
          <div
            key={name}
            id={`tabpanel-${i}`}
            role="tabpanel"
            aria-labelledby={`tab-${i}`}
            hidden={activeTab !== i}
          >
            {i === 0 ? (
              <>
                <ClimateCard />
                <HeatLossTab />
              </>
            ) : i === 1 ? (
              <EquipmentTab />
            ) : i === 2 ? (
              <HydraulicsTab />
            ) : i === 3 ? (
              <UfhTab />
            ) : (
              <EmptyTabState tabName={name} />
            )}
          </div>
        ))}
      </main>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: 'var(--color-surface)',
            color: 'var(--color-text-primary)',
            border: '1px solid var(--color-border)'
          }
        }}
        richColors
      />
    </div>
  )
}
