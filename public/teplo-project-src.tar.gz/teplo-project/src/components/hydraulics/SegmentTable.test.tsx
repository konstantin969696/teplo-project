/**
 * Tests for SegmentTable.
 * Covers: empty render (no rows), rows rendered for each segment.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, render, screen } from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { SegmentTable } from './SegmentTable'
import { useSegmentStore } from '../../store/segmentStore'
import { useProjectStore } from '../../store/projectStore'
import { useCoolantCatalogStore } from '../../store/coolantCatalogStore'
import { usePipeCatalogStore } from '../../store/pipeCatalogStore'

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}))

vi.spyOn(window, 'confirm').mockReturnValue(true)

beforeEach(() => {
  act(() => {
    useSegmentStore.setState({ segments: {}, segmentOrder: [] })
    useCoolantCatalogStore.getState().resetToSeed()
    usePipeCatalogStore.getState().resetToSeed()
    useProjectStore.setState({ coolantId: 'water', tSupply: 80, tReturn: 60 })
  })
})

afterEach(() => {
  vi.restoreAllMocks()
})

describe('SegmentTable', () => {
  it('renders table header with column names', () => {
    render(<SegmentTable />)
    expect(screen.getByText('Назначение')).toBeInTheDocument()
    expect(screen.getByText('Q, Вт')).toBeInTheDocument()
    expect(screen.getByText('L, м')).toBeInTheDocument()
    expect(screen.getByText('ΔP, Па')).toBeInTheDocument()
  })

  it('renders no rows when no segments', () => {
    const { container } = render(<SegmentTable />)
    const tbody = container.querySelector('tbody')
    expect(tbody?.children.length).toBe(0)
  })

  it('renders a row for each segment', () => {
    act(() => {
      useSegmentStore.getState().addSegment({
        parentSegmentId: null, name: 'Участок 1',
        equipmentId: null, qOverride: 1000, lengthM: 5,
        pipeId: 'steel-vgp-dn20', dnMm: null, kmsCounts: {}, velocityTargetMS: 0.6,
      })
      useSegmentStore.getState().addSegment({
        parentSegmentId: null, name: 'Участок 2',
        equipmentId: null, qOverride: 500, lengthM: 3,
        pipeId: 'steel-vgp-dn20', dnMm: null, kmsCounts: {}, velocityTargetMS: 0.6,
      })
    })
    render(<SegmentTable />)
    expect(screen.getByDisplayValue('Участок 1')).toBeInTheDocument()
    expect(screen.getByDisplayValue('Участок 2')).toBeInTheDocument()
  })
})
