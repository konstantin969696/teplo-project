/** Phase 4 types — hydraulics + UFH. Consumed by stores/engine/UI. */

// Schema type (HYDR-01 — метка для PDF, D-04)
export type SchemaType = 'two-pipe-dead-end' | 'two-pipe-flow-through' | 'manifold' | 'single-pipe'

export type PipeMaterial = 'steel-vgp' | 'copper' | 'pe-x' | 'pe-rt' | 'mlcp' | 'ppr'

export interface PipeSpec {
  readonly id: string
  readonly material: PipeMaterial
  readonly dnMm: number           // номинальный диаметр (для steel) или внешний (для pe-x)
  readonly innerDiameterMm: number
  readonly roughnessMm: number    // Δ_э, шероховатость
  readonly wallThicknessMm: number
  readonly maxLoopLengthM: number | null  // для UFH; null для магистральных
  readonly isCustom: boolean
}

export interface KmsItem {
  readonly id: string
  readonly name: string           // "Колено 90°", "Тройник проход", ...
  readonly zeta: number           // ζ коэффициент
  readonly isCustom: boolean
}

export interface CoolantSpec {
  readonly id: string
  readonly name: string           // "Вода", "Гликоль 30%", "Гликоль 40%"
  readonly rhoKgM3: number        // ρ при средней tсистемы
  readonly cKjKgK: number         // c, кДж/(кг·К)
  readonly nuM2S: number          // ν в м²/с (НЕ ×10⁶, хранить в СИ)
  readonly isCustom: boolean
}

export type KmsCounts = Readonly<Record<string, number>>  // kmsId -> count

export interface Segment {
  readonly id: string
  readonly parentSegmentId: string | null
  readonly name: string                  // "Магистраль 1", "Стояк 1/1", ...
  readonly equipmentId: string | null    // ссылка на equipmentStore; null для магистрали
  readonly qOverride: number | null      // Q ручной override (Вт), null = auto
  readonly lengthM: number
  readonly pipeId: string                // ссылка на pipeCatalog
  readonly dnMm: number | null           // принятый DN; null = авто
  readonly kmsCounts: KmsCounts
  readonly velocityTargetMS: number      // дефолт 0.6
}

// Derived graph node (не хранится, строится в селекторе)
export interface SegmentNode {
  readonly id: string
  readonly parentId: string | null
  readonly children: readonly string[]
  readonly deltaP: number
}

export type FloorCovering = 'tile' | 'laminate' | 'parquet' | 'linoleum'

export interface UfhLoop {
  readonly id: string
  readonly roomId: string
  readonly enabled: boolean           // если false — не учитывается в Q cascade
  readonly activeAreaM2: number       // F_тп, дефолт 0.8·room.area (D-07)
  readonly covering: FloorCovering
  readonly pipeId: string             // PE-X/PE-RT/MLCP из pipeCatalog
  readonly stepCm: number             // шаг укладки, 10..30
  readonly leadInM: number            // подводка, дефолт 3
}

export interface PumpRecommendation {
  readonly flowM3H: number
  readonly headM: number
  readonly deltaPGckPa: number
}

export interface BranchImbalance {
  readonly branchId: string
  readonly deltaPPa: number
  readonly imbalancePct: number       // (1 - ΔP_ветви/ΔP_ГЦК)·100
  readonly requiredKvs: number        // м³/ч
}
