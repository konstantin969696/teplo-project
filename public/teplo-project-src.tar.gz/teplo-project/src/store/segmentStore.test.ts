import { describe, it, expect, beforeEach } from 'vitest'
import { useSegmentStore, selectSegmentsByParent } from './segmentStore'
import type { Segment } from '../types/hydraulics'

const makeSegment = (overrides: Partial<Omit<Segment, 'id'>> = {}): Omit<Segment, 'id'> => ({
  parentSegmentId: null,
  name: 'Магистраль 1',
  equipmentId: null,
  qOverride: null,
  lengthM: 10,
  pipeId: 'steel-vgp-dn20',
  dnMm: 20,
  kmsCounts: {},
  velocityTargetMS: 0.6,
  ...overrides
})

beforeEach(() => {
  useSegmentStore.setState({ segments: {}, segmentOrder: [] })
  localStorage.clear()
})

describe('useSegmentStore', () => {
  describe('addSegment', () => {
    it('Test 1: returns id, adds to segmentOrder', () => {
      const id = useSegmentStore.getState().addSegment(makeSegment())
      const state = useSegmentStore.getState()
      expect(typeof id).toBe('string')
      expect(id.length).toBeGreaterThan(0)
      expect(state.segmentOrder).toContain(id)
      expect(state.segments[id]).toBeDefined()
      expect(state.segments[id].name).toBe('Магистраль 1')
    })

    it('multiple adds append to segmentOrder in order', () => {
      const id1 = useSegmentStore.getState().addSegment(makeSegment({ name: 'Seg 1' }))
      const id2 = useSegmentStore.getState().addSegment(makeSegment({ name: 'Seg 2' }))
      const id3 = useSegmentStore.getState().addSegment(makeSegment({ name: 'Seg 3' }))
      expect(useSegmentStore.getState().segmentOrder).toEqual([id1, id2, id3])
    })
  })

  describe('updateSegment', () => {
    it('Test 2: partial update preserves other fields', () => {
      const id = useSegmentStore.getState().addSegment(makeSegment({ lengthM: 5 }))
      useSegmentStore.getState().updateSegment(id, { name: 'Стояк 1' })
      const seg = useSegmentStore.getState().segments[id]
      expect(seg.name).toBe('Стояк 1')
      expect(seg.lengthM).toBe(5)
      expect(seg.pipeId).toBe('steel-vgp-dn20')
    })

    it('is a no-op for nonexistent id', () => {
      const before = Object.keys(useSegmentStore.getState().segments).length
      useSegmentStore.getState().updateSegment('nonexistent', { name: 'X' })
      expect(Object.keys(useSegmentStore.getState().segments).length).toBe(before)
    })
  })

  describe('deleteSegment', () => {
    it('Test 3: orphan handling — children get parentSegmentId=null', () => {
      const parentId = useSegmentStore.getState().addSegment(makeSegment({ name: 'Parent' }))
      const childId = useSegmentStore.getState().addSegment(makeSegment({ name: 'Child', parentSegmentId: parentId }))
      const grandchildId = useSegmentStore.getState().addSegment(makeSegment({ name: 'Grandchild', parentSegmentId: childId }))

      useSegmentStore.getState().deleteSegment(parentId)

      const state = useSegmentStore.getState()
      expect(state.segments[parentId]).toBeUndefined()
      expect(state.segments[childId].parentSegmentId).toBeNull()
      expect(state.segments[grandchildId].parentSegmentId).toBe(childId) // not affected
      expect(state.segmentOrder).not.toContain(parentId)
    })

    it('removes segment from segmentOrder', () => {
      const id = useSegmentStore.getState().addSegment(makeSegment())
      useSegmentStore.getState().deleteSegment(id)
      expect(useSegmentStore.getState().segmentOrder).not.toContain(id)
      expect(useSegmentStore.getState().segments[id]).toBeUndefined()
    })
  })

  describe('deleteByEquipmentId', () => {
    it('Test 4: cascade delete by equipmentId', () => {
      const equipId = 'eq-abc'
      const id1 = useSegmentStore.getState().addSegment(makeSegment({ equipmentId: equipId }))
      const id2 = useSegmentStore.getState().addSegment(makeSegment({ equipmentId: equipId }))
      const otherId = useSegmentStore.getState().addSegment(makeSegment({ equipmentId: 'eq-other' }))

      useSegmentStore.getState().deleteByEquipmentId(equipId)

      const state = useSegmentStore.getState()
      expect(state.segments[id1]).toBeUndefined()
      expect(state.segments[id2]).toBeUndefined()
      expect(state.segments[otherId]).toBeDefined()
    })

    it('orphans children of deleted equipment segments', () => {
      const equipId = 'eq-xyz'
      const parentId = useSegmentStore.getState().addSegment(makeSegment({ equipmentId: equipId }))
      const childId = useSegmentStore.getState().addSegment(makeSegment({ parentSegmentId: parentId }))

      useSegmentStore.getState().deleteByEquipmentId(equipId)

      expect(useSegmentStore.getState().segments[childId].parentSegmentId).toBeNull()
    })

    it('no-op when no segments match equipmentId', () => {
      useSegmentStore.getState().addSegment(makeSegment())
      const before = Object.keys(useSegmentStore.getState().segments).length
      useSegmentStore.getState().deleteByEquipmentId('nonexistent')
      expect(Object.keys(useSegmentStore.getState().segments).length).toBe(before)
    })
  })

  describe('reorderSegments', () => {
    it('Test 5: changes segmentOrder', () => {
      const id1 = useSegmentStore.getState().addSegment(makeSegment({ name: 'A' }))
      const id2 = useSegmentStore.getState().addSegment(makeSegment({ name: 'B' }))
      const id3 = useSegmentStore.getState().addSegment(makeSegment({ name: 'C' }))

      useSegmentStore.getState().reorderSegments([id3, id1, id2])
      expect(useSegmentStore.getState().segmentOrder).toEqual([id3, id1, id2])
    })
  })

  describe('updateKmsCount', () => {
    it('Test 6: adds kms entry when count > 0', () => {
      const id = useSegmentStore.getState().addSegment(makeSegment())
      useSegmentStore.getState().updateKmsCount(id, 'elbow-90-smooth', 3)
      expect(useSegmentStore.getState().segments[id].kmsCounts['elbow-90-smooth']).toBe(3)
    })

    it('removes kms entry when count = 0', () => {
      const id = useSegmentStore.getState().addSegment(makeSegment({ kmsCounts: { 'valve-ball': 2 } }))
      useSegmentStore.getState().updateKmsCount(id, 'valve-ball', 0)
      expect(useSegmentStore.getState().segments[id].kmsCounts['valve-ball']).toBeUndefined()
    })

    it('preserves other kms entries on update', () => {
      const id = useSegmentStore.getState().addSegment(makeSegment({ kmsCounts: { 'elbow-90-smooth': 2, 'valve-ball': 1 } }))
      useSegmentStore.getState().updateKmsCount(id, 'elbow-90-smooth', 4)
      const counts = useSegmentStore.getState().segments[id].kmsCounts
      expect(counts['elbow-90-smooth']).toBe(4)
      expect(counts['valve-ball']).toBe(1)
    })
  })

  describe('clearAllSegments', () => {
    it('clears segments and segmentOrder', () => {
      useSegmentStore.getState().addSegment(makeSegment())
      useSegmentStore.getState().addSegment(makeSegment())
      useSegmentStore.getState().clearAllSegments()
      expect(Object.keys(useSegmentStore.getState().segments)).toHaveLength(0)
      expect(useSegmentStore.getState().segmentOrder).toHaveLength(0)
    })
  })

  describe('bulkAddSegments', () => {
    it('adds multiple segments and returns ids in order', () => {
      const segs = [
        makeSegment({ name: 'Bulk A' }),
        makeSegment({ name: 'Bulk B' }),
        makeSegment({ name: 'Bulk C' })
      ]
      const ids = useSegmentStore.getState().bulkAddSegments(segs)
      expect(ids).toHaveLength(3)
      const state = useSegmentStore.getState()
      expect(state.segments[ids[0]].name).toBe('Bulk A')
      expect(state.segments[ids[1]].name).toBe('Bulk B')
      expect(state.segments[ids[2]].name).toBe('Bulk C')
      expect(state.segmentOrder.slice(-3)).toEqual([...ids])
    })
  })

  describe('persist key isolation', () => {
    it('persist key is teplo-segments', () => {
      useSegmentStore.getState().addSegment(makeSegment())
      expect(localStorage.getItem('teplo-segments')).not.toBeNull()
    })
  })
})

describe('selectSegmentsByParent', () => {
  beforeEach(() => {
    useSegmentStore.setState({ segments: {}, segmentOrder: [] })
  })

  it('returns root segments (parentId=null) in order', () => {
    const id1 = useSegmentStore.getState().addSegment(makeSegment({ name: 'Root 1', parentSegmentId: null }))
    const id2 = useSegmentStore.getState().addSegment(makeSegment({ name: 'Root 2', parentSegmentId: null }))
    const childId = useSegmentStore.getState().addSegment(makeSegment({ name: 'Child', parentSegmentId: id1 }))

    const state = useSegmentStore.getState()
    const roots = selectSegmentsByParent(null)(state)
    expect(roots.map(s => s.id)).toEqual([id1, id2])
    expect(roots.find(s => s.id === childId)).toBeUndefined()
  })

  it('returns children of a given parent', () => {
    const parentId = useSegmentStore.getState().addSegment(makeSegment({ name: 'Parent' }))
    const c1 = useSegmentStore.getState().addSegment(makeSegment({ name: 'Child 1', parentSegmentId: parentId }))
    const c2 = useSegmentStore.getState().addSegment(makeSegment({ name: 'Child 2', parentSegmentId: parentId }))

    const state = useSegmentStore.getState()
    const children = selectSegmentsByParent(parentId)(state)
    expect(children.map(s => s.id)).toEqual([c1, c2])
  })
})
