/**
 * UFH action bar — global tSupplyUfh/tReturnUfh inputs (D-08).
 * Wired to projectStore; clamp lives in setter (T-04-17 mitigation).
 * «Каталог теплоносителей…» button opens existing CoolantCatalogModal.
 */

import { useState, type ChangeEvent } from 'react'
import { useProjectStore } from '../../store/projectStore'
import { CoolantCatalogModal } from '../hydraulics/CoolantCatalogModal'
import { ColumnHint } from '../ColumnHint'
import { INPUT_CLASS } from './ufh-help'

export function UfhActionBar() {
  const tSupplyUfh = useProjectStore(s => s.tSupplyUfh)
  const tReturnUfh = useProjectStore(s => s.tReturnUfh)
  const setTSupplyUfh = useProjectStore(s => s.setTSupplyUfh)
  const setTReturnUfh = useProjectStore(s => s.setTReturnUfh)
  const [showCoolantCatalog, setShowCoolantCatalog] = useState(false)

  const handleNumber = (setter: (n: number) => void) =>
    (e: ChangeEvent<HTMLInputElement>) => {
      const v = parseFloat(e.target.value)
      if (Number.isFinite(v)) setter(v)
    }

  return (
    <div className="flex flex-col gap-2 p-3 border border-[var(--color-border)] rounded-md bg-[var(--color-surface)]">
      <div className="flex items-center gap-4 flex-wrap">
        <label className="flex items-center gap-2 text-sm text-[var(--color-text-primary)]">
          <ColumnHint
            label="tподача ТП, °C"
            hint="Температура подачи теплоносителя в контуры тёплого пола. Диапазон 30..60°C. Дефолт 45°C."
          />
          <input
            type="number"
            min={30}
            max={60}
            step={1}
            value={tSupplyUfh}
            onChange={handleNumber(setTSupplyUfh)}
            className={`${INPUT_CLASS} w-20 font-mono`}
            aria-label="Температура подачи ТП"
          />
        </label>
        <label className="flex items-center gap-2 text-sm text-[var(--color-text-primary)]">
          <ColumnHint
            label="tобратная ТП, °C"
            hint="Температура обратки теплоносителя из контуров тёплого пола. Диапазон 25..55°C. Дефолт 35°C."
          />
          <input
            type="number"
            min={25}
            max={55}
            step={1}
            value={tReturnUfh}
            onChange={handleNumber(setTReturnUfh)}
            className={`${INPUT_CLASS} w-20 font-mono`}
            aria-label="Температура обратки ТП"
          />
        </label>
        <button
          type="button"
          onClick={() => setShowCoolantCatalog(true)}
          className="ml-auto px-3 py-1 text-xs border border-[var(--color-border)] rounded hover:bg-[var(--color-bg)] text-[var(--color-text-primary)] transition-colors"
          aria-label="Открыть каталог теплоносителей"
        >
          Каталог теплоносителей…
        </button>
      </div>
      <CoolantCatalogModal open={showCoolantCatalog} onClose={() => setShowCoolantCatalog(false)} />
    </div>
  )
}
